# Physics Parameters
+ dampingMass
+ damingStiffness
+ surfaceDensity
+ tensileStiffness
+ shearStiffness
+ bendStiffnessU
+ bendStiffnessV

# Const. parameters
+ gravityForce

# Simulation Paramters
+ timeStep

# Computation Parameters
+ computeStretchShearForce, computeStretchShearStiffness, computeBendForce, computeBendStiffness  
+ numInternalForceThreads
+ numSolverThreads

# Output Parameters
+ u (records current deformation)
+ f_ext (records current external force)

# Model Objects
>	ClothBW * clothBW = NULL;
>	ClothBWStencilForceModel * clothBWStencilForceModel = NULL;
>	ForceModelAssembler * forceModelAssembler = NULL;
>	ObjMesh * objMesh = NULL;
>	ClothBWFromObjMesh * clothBWFromObjMesh = NULL;

# Solver Object
>	IntegratorBase * integratorBase = NULL;
>	ImplicitNewmarkSparse * implicitNewmarkSparse = NULL;
>	ImplicitBackwardEulerSparse * implicitBackwardEulerSparse = NULL;
>	ForceModel * forceModel = NULL;
>	SparseMatrix * massMatrix = NULL;

# initScene()
	I need to turn the following segments into one function that can be called from a defined library/header 
	In the simulator, this function is called everytime when a **new set** of parameters are updated.
### load OBJ Mesh
>	  if (objMesh != NULL)
>	    delete objMesh;
>	  objMesh = new ObjMesh(objMeshname);

### declare clothBWFromObjMesh
>	  if (clothBWFromObjMesh != NULL)
>	    delete clothBWFromObjMesh;
>	  clothBWFromObjMesh = new ClothBWFromObjMesh();

### Add in physical parameters
>	  if (clothBW != NULL)
>	   delete clothBW;
>	  ClothBW::MaterialGroup material;
>	  material.tensileStiffness = tensileStiffness;
>	  material.shearStiffness = shearStiffness;
>	  material.bendStiffnessU = bendStiffnessU;
>	  material.bendStiffnessV = bendStiffnessV;
>	  clothBW = clothBWFromObjMesh->GenerateClothBW(objMesh, surfaceDensity, material, addGravity);
>	  clothBW->SetGravity(addGravity, gravityForce);

### Construct Force models
>	  clothBWStencilForceModel = new ClothBWStencilForceModel(clothBW);
>	  forceModelAssembler = new ForceModelAssembler(clothBWStencilForceModel);
>	  forceModel = forceModelAssembler; 
>	  SparseMatrix * massMatrix;
>	  clothBW->GenerateMassMatrix(&massMatrix);
>	  double totalMass = massMatrix->SumEntries() / 3.0;
>	  printf("Total cloth mass: %G\n", totalMass);

### Add fixed points
	  numConstrainedDOFs = 3*numFixedVertices;
	  if (constrainedDOFs)
	    free(constrainedDOFs);
	  constrainedDOFs = (int*) malloc (sizeof(int) * numConstrainedDOFs);
	  for (int i=0; i<numFixedVertices; i++)
	  {
	    constrainedDOFs[3*i+0] = fixedVertices[i] * 3 + 0;
	    constrainedDOFs[3*i+1] = fixedVertices[i] * 3 + 1;
	    constrainedDOFs[3*i+2] = fixedVertices[i] * 3 + 2;
	  }

### Construct Solver
	  int numVertices = clothBW->GetNumVertices(); 
	  if (implicitBackwardEulerSparse != NULL)
	  delete implicitBackwardEulerSparse;
	  implicitBackwardEulerSparse = new ImplicitBackwardEulerSparse(3 * numVertices, timeStep, massMatrix, forceModel, numConstrainedDOFs, constrainedDOFs, dampingMass, dampingStiffness, 1, 1E-5, numSolverThreads);
	  implicitNewmarkSparse = implicitBackwardEulerSparse;
	  integratorBase = implicitNewmarkSparse;

### Set Solver data
	  if (u)
	    free(u);
	  if (f_ext)
	    free (f_ext);
	  u = (double*) malloc (sizeof(double) * 3 * numVertices);
	  f_ext = (double*) malloc (sizeof(double) * 3 * numVertices);
	  for(int i = 0 ; i < 3 * numVertices; i++)
	  {
	    u[i] = 0.0;
	    f_ext[i] = 0.0;
	  }
	  integratorBase->SetState(u);
	  integratorBase->SetExternalForces(f_ext);

# initGUI()
By looking at this function, one can know how to update a set of parameter

	  glui->add_edittext_to_panel(scene_option_panel,"tensileStiffness",GLUI_EDITTEXT_FLOAT,&tensileStiffness);
	  glui->add_edittext_to_panel(scene_option_panel,"shearStiffness",GLUI_EDITTEXT_FLOAT,&shearStiffness);
	  glui->add_edittext_to_panel(scene_option_panel,"bendStiffnessU",GLUI_EDITTEXT_FLOAT,&bendStiffnessU);
	  glui->add_edittext_to_panel(scene_option_panel,"bendStiffnessV",GLUI_EDITTEXT_FLOAT,&bendStiffnessV);
	  glui->add_edittext_to_panel(scene_option_panel,"dampingMass",GLUI_EDITTEXT_FLOAT,&dampingMass);
	  glui->add_edittext_to_panel(scene_option_panel,"dampingStiffness",GLUI_EDITTEXT_FLOAT,&dampingStiffness);
	  glui->add_edittext_to_panel(scene_option_panel,"gravityForce",GLUI_EDITTEXT_FLOAT,&gravityForce);
	  glui->add_edittext_to_panel(scene_option_panel,"mousePower",GLUI_EDITTEXT_FLOAT,&mouseForceCoeff);
	  glui->add_checkbox_to_panel(scene_option_panel,"useRestAngles", &useRestAngles);
	  glui->add_button_to_panel(scene_option_panel,"Upload Parameters",0, update_simulation_status);

To update the timestep 
>	integratorBase->SetTimestep(timeStep);
# OpenGL interface

### displayFunction
The deformation info is **set** by
>	sceneObjDeform->SetVertexDeformations(u);
The Vertex info is **get** by
>       sceneObjDeform->GetSingleVertexRestPosition(fixedVertices[i],
            &fixedVertexPos[0], &fixedVertexPos[1], &fixedVertexPos[2]);

### idleFunction
During simulation(runSimulation ==1), the external force was updated if a vertex is **dragged or wind is applied**.
>	integratorBase->AddExternalForces(f_ext);
Adding force/stiffness matrix toggling ability, set computation mode for the model
    bool parameters[4]; 
    parameters[0] = computeStretchShearForce;
    parameters[1] = computeBendForce;
    parameters[2] = computeStretchShearStiffness;
    parameters[3] = computeBendStiffness;
    
    clothBW->SetComputationMode(parameters);
    clothBW->UseRestAnglesForBendingForces(useRestAngles);

Updating all Force 
>	integratorBase->DoTimestep(); // the big timestep

Retrieve the displacement change
>	memcpy(u, integratorBase->Getq(), sizeof(double) * 3 * n);

# Interaction features
+ initGUI  
+ mouseMotion  
+ mouseButtonActivityFunction  
+ mouseMotionFunction  