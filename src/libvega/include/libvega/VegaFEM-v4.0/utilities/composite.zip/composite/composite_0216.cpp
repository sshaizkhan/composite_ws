/*************************************************************************
 *                                                                       *
 * Vega FEM Simulation Library Version 4.0                               *
 *                                                                       *
 * "Cloth simulator" application,                                        *
 * Copyright (C) 2007 CMU, 2009 MIT, 2018 USC                            *
 *                                                                       *
 * All rights reserved.                                                  *
 *                                                                       *
 * Code authors: Andy Pierce, Yijing Li, Yu Yu Xu, Jernej Barbic         *
 * http://www.jernejbarbic.com/vega                                      *
 *                                                                       *
 * Research: Jernej Barbic, Hongyi Xu, Yijing Li,                        *
 *           Danyong Zhao, Bohan Wang,                                   *
 *           Fun Shing Sin, Daniel Schroeder,                            *
 *           Doug L. James, Jovan Popovic                                *
 *                                                                       *
 * Funding: National Science Foundation, Link Foundation,                *
 *          Singapore-MIT GAMBIT Game Lab,                               *
 *          Zumberge Research and Innovation Fund at USC,                *
 *          Sloan Foundation, Okawa Foundation,                          *
 *          USC Annenberg Foundation                                     *
 *                                                                       *
 * This utility is free software; you can redistribute it and/or         *
 * modify it under the terms of the BSD-style license that is            *
 * included with this library in the file LICENSE.txt                    *
 *                                                                       *
 * This utility is distributed in the hope that it will be useful,       *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the file     *
 * LICENSE.TXT for more details.                                         *
 *                                                                       *
 *************************************************************************/

// #include <math.h>
// #include <vector>
#include "composite_interface.hpp"
#include "GL/glui.h"
#include "initGraphics.h"
#include "performanceCounter.h"
// #include "objMesh.h"
// #include "clothBWFromObjMesh.h"

// #include "clothBWStencilForceModel.h"
// #include "forceModelAssembler.h"

// #include "implicitNewmarkSparse.h"
// #include "implicitBackwardEulerSparse.h"
#include "configFile.h"
#include "listIO.h"
// #include "sceneObjectDeformable.h"
#include "saveScreenShot.h"

// #include "constrainedDOFs.h"
/*
  Driver for cloth simulation. Cloth is implemented using:

  Baraff and Witkin: Large Steps in Cloth Simulation, SIGGRAPH 1998. 
  David Pritchard: Implementing Baraff & Witkin's Cloth Simulation, May 2003, with minor updates April 2012
*/

#define Mm_PI 3.1415926
#define  MAX_FILE 4096



void initScene();

//glui
GLUI * glui = NULL;
GLUI_StaticText * systemSolveStaticText;
GLUI_StaticText * forceAssemblyStaticText;



// graphics
char windowTitleBase[4096] = "Composite Simulator";
int windowID;
int windowWidth = 800;
int windowHeight = 600;

//interactive control
double zNear = 0.01;               //default: 0.01
double zFar = 10.0;                //default:10.0;
double cameraRadius;
double focusPositionX, focusPositionY, focusPositionZ;
double cameraLongitude, cameraLatitude;
int g_iMenuId;			// mouse activity
int g_vMousePos[2];
int g_iLeftMouseButton,g_iMiddleMouseButton,g_iRightMouseButton;
double forceAssemblyTime = 0.0;
double systemSolveTime = 0.0;

// start out paused, wire-frame view, scene unlocked (you can drag to add forces)
int runSimulation=0, renderWireframe=1, saveScreenToFile=0, dragForce = 0, pulledVertex = -1, lockScene = 0, axis = 1, pin = 0, sprite=0, renderNormals = 0, displayMenu = 0, useTextures = 1;
int renderFixedVertices = 1;
int shiftPressed=0;
int altPressed=0;
int ctrlPressed=0;

int dragStartX, dragStartY;
std::vector<int> pin_points;
int graphicsFrame = 0;
Lighting * light = NULL;


char configFilename[MAX_FILE];
char lightingFilename[MAX_FILE];
// camera
SphericalCamera * camera = NULL;


PerformanceCounter timer;
double FPS = 0.0; 

PerformanceCounter display_timer;
double display_time = 0.0;
double dotimestep_time = 0.0;


// files
SceneObject * extraSceneGeometry = NULL;

//composite interface////////////////////////////////////////
Composite *sheet;
float density=0.046;
float timesteps = 0.05;
int iterations = 10;
float p[3]={8575.38, 8751.91, 0.000900105};
std::vector<double>vp;
double* deform;
std::vector<std::string> meshnames, training_data, robot_data;
int iter=0;
///////////////////////////////////////////////////////////
// This function specifies parameters (and default values, if applicable) for the
// configuration file. It then loads the config file and parses the options contained
// within. After parsing is complete, a list of parameters is printed to the terminal.
void initConfigurations()
{
  printf("Parsing configuration file %s...\n", configFilename);
  ConfigFile configFile;

  configFile.addOptionOptional("focusPositionX", &focusPositionX, 0.0);
  configFile.addOptionOptional("focusPositionY", &focusPositionY, 10.0);
  configFile.addOptionOptional("focusPositionZ", &focusPositionZ, 0.0);
  configFile.addOptionOptional("cameraRadius", &cameraRadius, 6.0);
  configFile.addOptionOptional("cameraLongitude", &cameraLongitude, -10.0);
  configFile.addOptionOptional("cameraLatitude", &cameraLatitude, 45.0);
  configFile.addOptionOptional("zBufferNear", &zNear, 0.01);
  configFile.addOptionOptional("zBufferFar", &zFar, 10.0);
  configFile.addOptionOptional("renderWireframe", &renderWireframe, renderWireframe);

  configFile.addOption("lightingFilename", lightingFilename);

  // statis scene geometry (optional)
  // configFile.addOptionOptional("extraSceneGeometryFilename", extraSceneGeometryFilename, "__none");
  
  // parse the configuration file
  if (configFile.parseOptions(configFilename) != 0)
  {
    printf("Error parsing options.\n");
    exit(1);
  }
 
  configFile.printOptions();
}

void Sync_GLUI()
{
  glui->sync_live();
}

void drawString(const char * str) 
{
  glPushAttrib(GL_LIGHTING_BIT | GL_CURRENT_BIT); // lighting and color mask
  glDisable(GL_LIGHTING);     // need to disable lighting for proper text color
  
  glColor3f(1.0, 1.0, 1.0); // set text color
  
  // loop all characters in the string
  while(*str)
  {
    glutBitmapCharacter(GLUT_BITMAP_8_BY_13, *str);
    ++str;
  }
  
  glEnable(GL_LIGHTING);
  glPopAttrib();
}



// this function does the following:
// (1) Clears display
// (2) Points camera at scene
// (3) Draws axes (if applicable) and sphere surrounding scene
// (4) Displays GUI menu
// (5) Sets cloth deformations
// (6) Sets lighting conditions
// (7) Builds surface normals for cloth (take this out to increase performance)
// (8) Renders cloth
// (9) Render pulled vertex in different color (if applicable)
void displayFunction()
{
  
  std::cout <<"display enter"<<std::endl;
  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_STENCIL_BUFFER_BIT);
  glMatrixMode(GL_MODELVIEW); 
  glLoadIdentity();	
  camera->Look();
  glStencilOp(GL_KEEP, GL_KEEP, GL_REPLACE);
  glStencilFunc(GL_ALWAYS, 0, ~(0u));

  // render any extra scene geometry
  glStencilFunc(GL_ALWAYS, 0, ~(0u));
  if (extraSceneGeometry != NULL)
  {
    // Vec3d colors=Vec3d(0.0,0.0,0.0);
    // std::vector<Vec3d> extra_color;
    // extra_color.push_back(colors);
    
    // extraSceneGeometry->SetCustomColor(extra_color);
    // glEnable(GL_LIGHTING);
      glDisable(GL_LIGHTING);
      glColor3f(0.5,1,0.2);
      extraSceneGeometry->Render();
      glEnable(GL_LIGHTING);


      glDisable(GL_LIGHTING);
      glColor3f(0,0,0);
      extraSceneGeometry->EnableFlatFaces();
      extraSceneGeometry->RenderFacesAndEdges();
      glEnable(GL_LIGHTING);
  }

  if(axis)
  {
    glDisable(GL_LIGHTING);
    glEnable(GL_COLOR_MATERIAL);

    glBegin(GL_LINES);
    for (int i = 0; i < 3; i++)
    {
      float color[3] = { 0, 0, 0 };
      color[i] = 1.0;
      glColor3fv(color);

      float vertex[3] = {0, 0, 0};
      vertex[i] = 1.0;
      glVertex3fv(vertex);
      glVertex3f(0, 0, 0);
    }
    glEnd();
    glEnable(GL_LIGHTING);
  }
 
  // if (displayMenu)
  //   display_menu(FPS);
  
  
  
  // render cloth
  if (sheet->getClothBW() != NULL)
  { 
    sheet->getSceneObj()->SetVertexDeformations(deform);
    glLineWidth(1.0);
    glStencilFunc(GL_ALWAYS, 1, ~(0u));
    //glEnable(GL_COLOR_MATERIAL);
    
    //sceneObjDeform->SetVertexDeformations(u);
    sheet->getSceneObj()->SetLighting(light);
    // std::cout <<"light set"<<std::endl;
    //sceneObjDeform->SetUpTextures(textureMode);
    //sceneObjDeform->BuildNormals();
    sheet->getSceneObj()->BuildNormalsFancy();
// std::cout <<"normal fancy"<<std::endl;
    if (renderNormals)
    {
      glDisable(GL_LIGHTING);
      glColor3f(0,0,1);
      sheet->getSceneObj()->RenderNormals();
      glEnable(GL_LIGHTING);
    }

    // render fixed vertices
    glDisable(GL_LIGHTING);
    if (renderFixedVertices)
    {
      for(int i=0; i<sheet->getFixedGroups().size(); i++)
      {
        glColor3f(1,0,0);
        double fixedVertexPos[3];
        sheet->getSceneObj()->GetSingleVertexRestPosition(sheet->getFixedGroups()[i],
            &fixedVertexPos[0], &fixedVertexPos[1], &fixedVertexPos[2]);

        glEnable(GL_POLYGON_OFFSET_POINT);
        glPolygonOffset(-1.0,-1.0);
        glPointSize(12.0);
        glBegin(GL_POINTS);
        glVertex3f(fixedVertexPos[0], fixedVertexPos[1], fixedVertexPos[2]);
        glEnd();
        glDisable(GL_POLYGON_OFFSET_FILL);
      }
    }
    
    glEnable(GL_LIGHTING);
    sheet->getSceneObj()->Render();

    if (renderWireframe)
    {
      glDisable(GL_LIGHTING);
      glColor3f(0,0,0);
      sheet->getSceneObj()->RenderEdges();
      glEnable(GL_LIGHTING);
    }
  }
  // else
  // {
  //   printf("Error: cloth object has not been created.\nExiting...\n");
  //   exit(1);
  // }
  
  // if pulling a vertex, render that vertex in diff color
  // if (pulledVertex != -1)
  // {
  //   glDisable(GL_LIGHTING);
  //   glDisable(GL_TEXTURE_2D);
    
  //   //sceneObjDeform->HighlightVertex(pulledVertex);
    
  //   glColor3f(1.0, 0.0, 0.0);
  //   glPointSize(8.5);
  //   glBegin(GL_POINTS);

  //   const Vec3d * restPos = sheet->getClothBW()->GetRestPositions();
  //   double vertexCoords[3];
  //   vertexCoords[0] = restPos[pulledVertex][0] + u[3*pulledVertex + 0];
  //   vertexCoords[1] = restPos[pulledVertex][1] + u[3*pulledVertex + 1];
  //   vertexCoords[2] = restPos[pulledVertex][2] + u[3*pulledVertex + 2];
  //   // std::cout << *restPos;
  //   //printf("Vertex: (%G, %G, %G)\n", vertexCoords[0], vertexCoords[1], vertexCoords[2]);
    
  //   glVertex3f(vertexCoords[0], vertexCoords[1], vertexCoords[2]);
    
  //   glEnd();
  //   glEnable(GL_TEXTURE_2D);
  //   glEnable(GL_LIGHTING);


  // }


  
  glStencilOp(GL_KEEP, GL_KEEP, GL_KEEP);
  glutSwapBuffers();
}

// this function does the following:
// (1) Takes a screenshot (if applicable)
// (2) Updates & displays the fps
// (3) Applies mouse forces
// (4) Applies wind forces
// (5) Sets computation mode for clothBW
// (6) Performs a timestep
void idleFunction(void)
{
  std::cout <<"idle enter"<<std::endl;
  // static int timeStepCount = 0;
  // float timestepsPerSecond = 1.0/sheet->getTimeStep();
  
  // glutSetWindow(windowID);
  
  // // recording
  // char s[70]="picxxxx.ppm\0";
  
  // s[40] = 48 + (sprite / 1000);
  // s[41] = 48 + (sprite % 1000) / 100;
  // s[42] = 48 + (sprite % 100 ) / 10;
  // s[43] = 48 + sprite % 10;
  
  // if (saveScreenToFile==1 && timeStepCount<timestepsPerSecond*10)
  // {
  //   Screenshot::SaveScreenshot(s, ImageIO::FORMAT_PNG, windowWidth, windowHeight);
  //   //saveScreenToFile=0; // save only once, change this if you want continuous image generation (i.e. animation)
  //   sprite++;
  // }
  // if (timeStepCount>timestepsPerSecond*10 && saveScreenToFile)
  // {
  //   printf("DONE!\n");
  //   // runSimulation = 0;
  //   saveScreenToFile = 0;
  // }
  // if (sprite >= 300) // allow only 300 snapshots
  //   exit(0);	
  
  // external force & time step
  // if (runSimulation == 1) // if unpaused
  // {
  //   // clear old external force
    // integratorBase->SetExternalForcesToZero();
    
  //   // external forces
    
  //   // user mouse forces
  //   if((g_iLeftMouseButton && pulledVertex != -1 && lockScene == 0))
  //   {
  //     double forceX = (g_vMousePos[0] - dragStartX);
  //     double forceY = -(g_vMousePos[1] - dragStartY);
      
  //     //add external force here
  //     double externalForce[3];
  //     camera->CameraVector2WorldVector_OrientationOnly3D(forceX, forceY, 0, externalForce);	
  //     for(int i = 0 ; i < 3; i++)
  //       externalForce[i] *= mouseForceCoeff;
  //     //printf("fx: %G fy: %G | %G %G %G\n", forceX, forceY, externalForce[0], externalForce[1], externalForce[2]);
      
  //     memset(f_ext, 0.0, 3*n);
  //     for(int i = 0 ; i < 3; i++)
  //       f_ext[3*pulledVertex+i] += externalForce[i];
      
  //     integratorBase->AddExternalForces(f_ext);
  //   }

  //   // wind forces
  //   for(int i = 0 ; i < clothBW->GetNumVertices(); i++)
  //   {
  //     f_ext[3*i+0] = wind_x;
  //     f_ext[3*i+1] = wind_y;
  //     f_ext[3*i+2] = wind_z;
  //   }
  //   integratorBase->AddExternalForces(f_ext);
    
  //   if(constrain_test==1)
  //   {
  //     // std::cout << "k pressed\n";
  //     double* qdelta;
  //     memset(qdelta, 0, sizeof(double) * 3 * n);
  //     // ConstrainedDOFs::InsertDOFs(3*n, integratorBase->Getq(), qdelta, numfixpnt, fixpnt);

  //     // integratorBase->SetState(qdelta);
  //     for(int i=0; i<numfixpnt; i++)
  //       integratorBase->SetQ(u[fixpnt[i]],0);
  //     // integratorBase->DoTimestep();
  //     // memcpy(u,integratorBase->Getq(),sizeof(double) *3*n);
  //   }
    
  //   // adding force/stiffness matrix toggling ability
  //   bool parameters[4]; 
  //   parameters[0] = computeStretchShearForce;
  //   parameters[1] = computeBendForce;
  //   parameters[2] = computeStretchShearStiffness;
  //   parameters[3] = computeBendStiffness;
    
  //   clothBW->SetComputationMode(parameters);
  //   clothBW->UseRestAnglesForBendingForces(useRestAngles);
    
  //   integratorBase->DoTimestep(); // the big timestep
  //   timeStepCount++;

  //   memcpy(u, integratorBase->Getq(), sizeof(double) * 3 * n);
    
  //   sceneObjDeform->BuildFaceNormals();
  // }

  // fps
  std::cout <<"current iter: "<<iter<<std::endl;
  deform=sheet->solve_config(meshnames[iter].data(),robot_data[iter].data(),iterations);
  std::cout <<"Scene updated: "<<sheet->getSceneObj()->Getn()<<std::endl;
  iter++;
  if(iter == meshnames.size())
    iter=0;
  // std::cout <<"Scene updated"<<sheet->getSceneObj()->Getn()<<std::endl;
  // timer.StopCounter();
  // double elapsedTime = timer.GetElapsedTime();  
  // if (elapsedTime >= 1.0 / 4)  
  // {
  //   timer.StartCounter(); 
  //   FPS = graphicsFrame / elapsedTime;

  //   forceAssemblyTime = sheet->getImplicitNewmarkSparse()->GetForceAssemblyTime();
  //   systemSolveTime = sheet->getImplicitNewmarkSparse()->GetSystemSolveTime();

  //   char ptext[96];
  //   sprintf(ptext, "Force assembly: %G", forceAssemblyTime);
  //   forceAssemblyStaticText->set_text(ptext);
  //   sprintf(ptext, "System solve: %G", systemSolveTime);
  //   systemSolveStaticText->set_text(ptext);
  //   // Sync_GLUI();

  //   graphicsFrame = 0;
  // }
 
  // graphicsFrame++;
  // std::cout<< "frame++"<<std::endl; 
  glutPostRedisplay();
  // std::cout<< "post"<<std::endl;
}

void reshape(int x,int y)
{
  std::cout<< "reshape"<<std::endl;
  glViewport(0,0,x,y);
  
  windowWidth = x;
  windowHeight = y;
  
  glMatrixMode(GL_PROJECTION); // Select The Projection Matrix
  glLoadIdentity(); // Reset The Projection Matrix
  
  // gluPerspective(90.0,1.0,0.01,1000.0);
  gluPerspective(60.0f, 1.0 * windowWidth / windowHeight, zNear, zFar);
  
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
}

void exit_buttonCallBack(int code)
{
  // free memory
  std::cout<< "exit_buttonCallBack"<<std::endl;
  sheet->ResetInstance();
  
  exit(0);
}

void keyboardFunction(unsigned char key, int x, int y)
{

}

// reacts to pressed "special" keys
void specialFunction(int key, int x, int y)
{
  // std::cout<< "specialFunction"<<std::endl;
  // switch (key)
  // {
  //   case GLUT_KEY_LEFT:
  //     camera->MoveFocusRight(+0.1 * camera->GetRadius());
  //   break;

  //   case GLUT_KEY_RIGHT:
  //     camera->MoveFocusRight(-0.1 * camera->GetRadius());
  //   break;

  //   case GLUT_KEY_DOWN:
  //     camera->MoveFocusUp(+0.1 * camera->GetRadius());
  //   break;

  //   case GLUT_KEY_UP:
  //     camera->MoveFocusUp(-0.1 * camera->GetRadius());
  //   break;

  //   case GLUT_KEY_PAGE_UP:
  //     break;

  //   case GLUT_KEY_PAGE_DOWN:
  //     break;

  //   case GLUT_KEY_HOME:
  //     break;

  //   case GLUT_KEY_END:
  //     break;

  //   case GLUT_KEY_INSERT:
  //     break;

  //   default:
  //     break;
  // }
}

void mouseMotion (int x, int y)
{
  // std::cout<< "mouseMotion"<<std::endl;
  // g_vMousePos[0] = x;
  // g_vMousePos[1] = y;
}

void mouseButtonActivityFunction(int button, int state, int x, int y)
{
  // std::cout<< "mouseButtonActivityFunction"<<std::endl;
  // switch (button)
  // {
  //   case GLUT_LEFT_BUTTON:
  //     g_iLeftMouseButton = (state==GLUT_DOWN);
  //     shiftPressed = (glutGetModifiers() == GLUT_ACTIVE_SHIFT);
  //     altPressed = (glutGetModifiers() == GLUT_ACTIVE_ALT);
  //     ctrlPressed = (glutGetModifiers() == GLUT_ACTIVE_CTRL);
  //     if (g_iLeftMouseButton)
  //     {
  //       GLdouble model[16];
  //       glGetDoublev (GL_MODELVIEW_MATRIX, model);
        
  //       GLdouble proj[16];
  //       glGetDoublev (GL_PROJECTION_MATRIX, proj);
        
  //       GLint view[4];
  //       glGetIntegerv (GL_VIEWPORT, view);
        
  //       int winX = x;
  //       int winY = view[3]-1-y;
        
  //       float zValue;
  //       glReadPixels(winX,winY,1,1, GL_DEPTH_COMPONENT, GL_FLOAT, &zValue); 
        
  //       GLubyte stencilValue;
  //       glReadPixels(winX, winY, 1, 1, GL_STENCIL_INDEX, GL_UNSIGNED_BYTE, &stencilValue);
        
  //       GLdouble worldX, worldY, worldZ;
  //       gluUnProject (winX, winY, zValue, model, proj, view, &worldX, &worldY, &worldZ);
        
  //       //printf("x:%d y:%d zValue:%f stencil:%d world: %f %f %f\n",
  //       //       winX,winY,zValue,stencilValue,worldX,worldY,worldZ);
        
  //       // if(lockScene == 0)
  //       // {
  //       //   if (stencilValue == 1)
  //       //   {
  //       //     dragStartX = x;
  //       //     dragStartY = y;
  //       //     //pulledVertex = renderCloth->findClosestVertex(clothBW, u, worldX, worldY, worldZ);
  //       //     Vec3d pos(worldX, worldY, worldZ);
  //       //     pulledVertex = sheet->getSceneObj()->GetClosestVertex(pos, u);
  //       //     printf("Clicked on vertex: %d (0-indexed)\n", pulledVertex);
  //       //     std::cout << sheet->getSceneObj()->GetSingleVertexPositionFromBuffer(pulledVertex);

  //       //     // std::cout << integratorBase->Getq()[fixedVertices[0]];

  //       //     // integratorBase->SetExternalForcesToZero();
  //       //     // integratorBase->SetQ(pulledVertex, 0);
  //       //     // integratorBase->DoTimestep();
  //       //     // memcpy(u, integratorBase->Getq(), sizeof(double) * 3 * n);
            

  //       //     // sceneObjDeform->BuildFaceNormals();
  //       //   }
  //       //   else
  //       //   {
  //       //     printf("Clicked on empty stencil: %d.\n", stencilValue);
  //       //     pulledVertex = -1;
  //       //   }
  //       // }
  //       // if(pin == 1)
  //       // {
  //       //   if (stencilValue == 1)
  //       //   {
  //       //     //int vertex = renderCloth->findClosestVertex(clothBW, u, worldX, worldY, worldZ);
  //       //     Vec3d pos(worldX, worldY, worldZ);
  //       //     int vertex = sheet->getSceneObj()->GetClosestVertex(pos, u);
  //       //     printf("Pinned on vertex: %d (0-indexed)\n", vertex);
  //       //     pin_points.push_back(vertex);
  //       //   }
  //       // }
  //       // if (!g_iLeftMouseButton)
  //       // {
  //       //   pulledVertex = -1;
  //       // }
  //     }
  //     // if (!g_iLeftMouseButton)
  //     //   pulledVertex = -1;
  //     break;
  //   case GLUT_MIDDLE_BUTTON:
  //     g_iMiddleMouseButton = (state==GLUT_DOWN);
  //     break;
  //   case GLUT_RIGHT_BUTTON:
  //     g_iRightMouseButton = (state==GLUT_DOWN);
  //     break;
  //   case 3:
  //     g_iMiddleMouseButton=3;
  //     break;
  //   case 4:
  //     g_iMiddleMouseButton=4;
  //     break;
  // }
  
  // g_vMousePos[0] = x;
  // g_vMousePos[1] = y;	
}

void mouseMotionFunction(int x, int y)
{
  // std::cout<< "mouseMotionFunction"<<std::endl;
  // int mouseDeltaX = x-g_vMousePos[0];
  // int mouseDeltaY = y-g_vMousePos[1];
  
  // g_vMousePos[0] = x;
  // g_vMousePos[1] = y;
  
  // if (g_iMiddleMouseButton) // handle camera rotations
  // {
  //   const double factor = 0.1;
  //   camera->MoveRight(factor * mouseDeltaX);
  //   camera->MoveUp(factor * mouseDeltaY);
  // } 
  
  // if (g_iRightMouseButton) // handle zoom in/out
  // {
  //   const double factor = 0.1;
  //   camera->ZoomIn(cameraRadius * factor * mouseDeltaX);
  // }

}




// this function does the following:
// (1) Creates the camera
// (2) Loads a .obj file
// (3) Creates a clothBW from the .obj file
// (4) Loads file containing constrained vertices
// (5) Creates an object to render the clothBW
// (6) Creates a lighting object to light the scene
// (7) Takes care of internal threading (if applicable)
// (8) Creates numerical integrator
// (9) Initializes textures on the cloth rendering object
void initScene()
{
  if(camera != NULL)	
    delete(camera);
  
  double virtualToPhysicalPositionFactor = 1.0;
  
  initCamera(cameraRadius, cameraLongitude, cameraLatitude,
             focusPositionX, focusPositionY, focusPositionZ,
             1.0 / virtualToPhysicalPositionFactor,
             &zNear, &zFar, &camera);
  if (light != NULL)
    delete light;
  light = new Lighting(lightingFilename);
  std::cout<< "Camera set"<<std::endl;
  // if(sheet->getSceneObj() == NULL)
  //   std::cout<< "obj unset"<<std::endl;
  // deform = sheet->solve_config(meshnames[iter].data(),robot_data[iter].data(),iterations);
  // std::cout<< "config set"<<std::endl;
  // if(sheet->getSceneObj() != NULL)
  //   std::cout<< "obj set"<<std::endl;
  
}



int main(int argc, char* argv[])
{
  int numFixedArgs = 2;
  
  if ( argc != numFixedArgs )
  {
    printf("=== Composite Simulator ===\n");
    printf("Usage: %s [config file]\n", argv[0]);
    printf("Please specify a configuration file\n");
    return 1;
  }
  else
  {
    strncpy(configFilename, argv[1], strlen(argv[1]));
  }
    const char* output = "/home/cam_sanding/VegaFEM-v4.0/utilities/composite_interface/param/param.txt";
  // // char* objMeshname="../../models/composite/rand_grid_data_90.obj";
  // // // char* fixfilename="../../models/composite/cloth5000.bou";
  // meshnames.push_back("../../examples/composite/sheet_90.obj");
  // // meshnames.push_back("../../examples/composite/sheet_90.obj");
  // // meshnames.push_back("../../models/cloth/bend1.obj");
  // fixindexfiles.push_back("../../models/composite/cloth5000.bou");
  std::string foldername = "/home/cam_sanding/camera_catkin_ws/src/ensenso_utilities/pcd_data";
  std::string meshpath;
  std::string trainingpath;
  std::string robotpath;
  for(int i=0; i<2;i++)
  {
    for(int j=0; j<5; j++){
      trainingpath = foldername + "/center_data/large_01292020/test/new_center_grip"+std::to_string(i+4)+"_curve_"+std::to_string(j+1)+".csv";
      meshpath = foldername + "/large_01292020/mesh"+std::to_string(i+4)+"_"+std::to_string(j+1)+".obj";
      robotpath = foldername + "/center_data/large_01292020/robot_data/new_center_grip"+std::to_string(i+4)+"_curve_"+std::to_string(j+1)+".csv";
      std::cout << trainingpath.data()<<std::endl;
      std::cout << meshpath.data()<<std::endl;
      meshnames.push_back(meshpath);
      meshpath.clear();
      training_data.push_back(trainingpath);
      trainingpath.clear();     
      robot_data.push_back(robotpath);
      robotpath.clear();
    }

  }
  // make window and size it properly
  initGLUT(argc, argv, windowTitleBase, windowWidth, windowHeight, &windowID);
  
  // define background texture, set some openGL parameters
  initGraphics(windowWidth, windowHeight);
  for(int i=0; i<(sizeof(p)/sizeof(*p));i++)
    vp.push_back(p[i]);
  sheet = Composite::getInstance();
  sheet->setTimeStep(timesteps);
  sheet->setDensity(density);
  sheet->updateParam(vp);


  // load info from config file
  // initConfigurations();
  initConfigurations();
  initScene();
  
  // initGLUI();
  
  glutMainLoop(); 
  return 0;
}

