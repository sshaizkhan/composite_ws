#include "composite_interface.hpp"
#include "sceneObjectDeformable.h"
#include "performanceCounter.h"
#include <iostream>
#include "configFile.h"
#include "listIO.h"
#include <string>

using namespace std;

bool Composite::instanceFlag = false;
Composite* Composite::sheet = NULL;

Composite::Composite():dampingMass(0.02),
dampingStiffness(0.03),surfaceDensity(0.04),
tensileStiffness(8500.0), shearStiffness(100.0),
bendStiffnessU(0.06),bendStiffnessV(0.06),
clothBW(NULL),sceneObjDeform(NULL), clothBWStencilForceModel(NULL),
forceModelAssembler(NULL),objMesh(NULL),
clothBWFromObjMesh(NULL),integratorBase(NULL),
implicitNewmarkSparse(NULL),implicitBackwardEulerSparse(NULL),meshname(NULL),
forceModel(NULL),massMatrix(NULL),computeStretchShearForce(1),computeStretchShearStiffness(1),computeBendForce(1),computeBendStiffness(1)
{
	// deformdata.resize(90);
	markerindex[0] = {320,1533,1531,1759};markerindex[31] = {295,296,409,521,1475,1476,1709,1717};markerindex[62] = {673,770,2022,1318};
	markerindex[1] = {446,1414,1415,1761};markerindex[32] = {406,259,973,407};markerindex[63] = {379,948,112,1653};
	markerindex[2] = {97,331,904,1184};markerindex[33] = {83,877,878,1100};markerindex[64] = {567,1119,1325,1927};
	markerindex[3] = {46,556,1110,1498};markerindex[34] = {702,1592,1594,1899};markerindex[65] = {422,985,1405,1408};
	markerindex[4] = {922,1496,1581,1582};markerindex[35] = {707,1597,1598,2039};markerindex[66] = {42,123,427,1737};
	markerindex[5] = {692,1438,1586,1803};markerindex[36] = {371,370,1816,1632};markerindex[67] = {171,1151,1154,1955};
	markerindex[6] = {471,1033,1435,1805};markerindex[37] = {860,1045,1046,1443};markerindex[68] = {389,810,960,959,1356,1673,1675,1676};
	markerindex[7] = {5,357,358,108};markerindex[38] = {373,751,1634,1826};markerindex[69] = {393,815,816,1360};
	markerindex[8] = {718,723,2054};markerindex[39] = {376,375,753,1643,1644};markerindex[70] = {344,915,916,1568};
	markerindex[9] = {215,1275,1276};markerindex[40] = {514,515,1878,1879};markerindex[71] = {233,1329,1330,1051,487,1832,2019,1833,1326,2018};
	markerindex[10] = {126,436,997,1411};markerindex[41] = {519,1703,1883,1884};markerindex[72] = {491,289,865,867,1457};
	markerindex[11] = {128,442,1003};markerindex[42] = {529,1091,1890};markerindex[73] = {499,1059,1061,1848,1338};
	markerindex[12] = {38,159,160,1105};markerindex[43] = {531,1096,1893,1894};markerindex[74] = {1128,1129,1340};
	markerindex[13] = {549,1109,1493};markerindex[44] = {703,742,1896,2036};markerindex[75] = {890,891,1515,1516};
	markerindex[14] = {687,1233,1235,1909};markerindex[45] = {744,1628,1925,1930};markerindex[76] = {821,588,1362,1852,1948};
	markerindex[15] = {859,1027,1026,1432};markerindex[46] = {748,1819,1932,1933};markerindex[77] = {35,148,1064,1067};
	markerindex[16] = {136,1030,1031,1800};markerindex[47] = {757,1305,1951,1592};markerindex[78] = {870,1466,1468,1469};
	markerindex[17] = {217,727,1278,1280};markerindex[48] = {1638,1639,1958,1953};markerindex[79] = {1380,1376,1871,1872};
	markerindex[18] = {363,364,935,1619};markerindex[49] = {763,765,1962,1964};markerindex[80] = {656,1210,1211,2014};
	markerindex[19] = {218,219,730,1283,1284};markerindex[50] = {99,100,337,909};markerindex[81] = {237,788,1334,1337,1839,1662};
	markerindex[20] = {95,324,36,901};markerindex[51] = {460,1021,1217,1783};markerindex[82] = {798,241,1342,1843};
	markerindex[21] = {524,1089,1090,1720};markerindex[52] = {22,102,103,920};markerindex[83] = {26,387,956,1670,957};
	markerindex[22] = {69,261,841,842};markerindex[53] = {767,228,1313,2025};markerindex[84] = {583,1134,1348,1940};
	markerindex[23] = {119,976,1103,1711};markerindex[54] = {563,564,769,1502};markerindex[85] = {394,825,1370,1684};
	markerindex[24] = {207,1101,1242,1243};markerindex[55] = {308,572,885,1504};markerindex[86] = {253,827,1690,1859};
	markerindex[25] = {355,928,1601,1251};markerindex[56] = {125,430,124,1742};markerindex[87] = {149,505,1072,1069};
	markerindex[26] = {735,736,221,1810};markerindex[57] = {312,896,1521,1519};markerindex[88] = {256,834,1384,1694,399,1864};
	markerindex[27] = {476,863,1040,1447};markerindex[58] = {92,315,894,1524};markerindex[89] = {402,1701,1702,837};
	markerindex[28] = {143,144,484,1047,1048};markerindex[59] = {1350,244,809,1352};
	markerindex[29] = {750,1300,1829,1302};markerindex[60] = {131,452,642,1012};
	markerindex[30] = {516,616,1881,1880};markerindex[61] = {457,1016,1017,1779,1780};

	constrainGroups[0] = {598,1159,1161,1965,1967,1966};
	constrainGroups[1] = {720,721,722,2056,2058,2059,2060,2061};
	constrainGroups[2] = {838,839,2120,2121,2122,1388};

}
Composite* Composite::getInstance()
{
	if(!instanceFlag)
	{
		sheet = new Composite;
		instanceFlag= true;
	}
	return sheet;
}

void Composite::method(){
	cout << "success"<<endl;
	cout << "dampingMass: "<<dampingMass<<endl;
}
void Composite::getParameters(){
	cout << "dampingMass: "<<dampingMass<<endl;
	cout << "dampingStiffness: "<<dampingStiffness<<endl;
	cout << "surfaceDensity: "<<surfaceDensity<<endl;
	cout << "tensileStiffness: "<<tensileStiffness<<endl;
	cout << "shearStiffness: "<<shearStiffness<<endl;
	cout << "bendStiffnessU: "<<bendStiffnessU<<endl;
	cout << "bendStiffnessV: "<<bendStiffnessV<<endl;
	// cout <<"vertexNum: "<<numVertices<<endl;
}
void Composite::updateParam(const float* p){
	surfaceDensity = 4.6e-7;
	tensileStiffness = p[0];
	shearStiffness = p[1];
	bendStiffnessU = 0.005;
	bendStiffnessV = 0.005;
	dampingMass = 0.0;
	dampingStiffness = 0.1;
	// surfaceDensity = p[0];
	// tensileStiffness = p[1];
	// shearStiffness = p[2];
	// bendStiffnessU = p[3];
	// bendStiffnessV = p[4];
	// dampingMass = p[5];
	// dampingStiffness = p[6];
	// cout << "[Parameters updated]"<< endl;
}
void Composite::updateParam(const vector<double>& p){
	surfaceDensity = 0.46;
	tensileStiffness = p[0];
	shearStiffness = p[1];
	bendStiffnessU = p[2];
	bendStiffnessV = p[2];
	dampingMass = 0.0;
	dampingStiffness = 0.1;
	// 	surfaceDensity = p[0];
	// tensileStiffness = p[1];
	// shearStiffness = p[2];
	// bendStiffnessU = p[3];
	// bendStiffnessV = p[4];
	// dampingMass = p[5];
	// dampingStiffness = p[6];
	// cout << "[Parameters updated: "<< p[0]<<" "<< p[1]<<" "<< p[2]<<" "<< p[3]<<" "<< p[4]<<" "<< p[5]<<" "<< p[6]<<"]" <<endl;
}

void Composite::setTimeStep(const float& step){
	timeStep = step;
}

void Composite::loadMesh(const char* objMeshname){
	  if (objMesh != NULL)
	    delete objMesh;
	  objMesh = new ObjMesh(objMeshname);
	  meshname = objMesh->getFilename().c_str();
	  // cout <<"[Sheet loaded] - "<< objMesh->getFilename() <<endl;
}


std::vector<Vec3d> Composite::getVec3d(const char* realcoordname){
		vector<Vec3d> data;
		fstream fin;
	  	fin.open(realcoordname);
		if(!fin.is_open()){
			// std::cout<<"open failed"<<std::endl;
			return data;
		}
		std::string line;
		std::vector<std::string> coord;
		std::string value;
		// int count=0;
		// int i=0;
		while(getline(fin,line)){
				std::stringstream ss(line);
				coord.clear();
				while(getline(ss,value,',')){
					coord.push_back(value);
				}
				data.push_back(Vec3d(stod(coord[0]),stod(coord[1]),stod(coord[2])));
				// i++;
		}
		// std::cout<<"open done"<<std::endl;
		return data;
	}

void Composite::shiftMesh(const Vec3d& offset){
		for(int i=0; i<objMesh->getNumVertices();i++){
			objMesh->setPosition(i,objMesh->getPosition(i)+(offset*1000));
		}
		// cout << "[data shift]"<<endl;
	}
Vec3d Composite::getGroupCenter(const std::vector<int>& group){
	Vec3d Center(0,0,0);
	for(int i=0; i<group.size();i++)
		Center+=objMesh->getPosition(group[i])/1000.;
	// cout << objMesh->getPosition(group[0])/1000.<<endl;
	Center/=group.size();
	return Center;
}
int Composite::UpdateFixPosition(const char* indexfilename, const char* realcoordname){
		//read the file

	 	//make them into groups
	 	Vec3d Realfix[3];
	 	Vec3d Offset[3];
	 	Vec3d Center[3];
	 	getFixfromfile(indexfilename);
	 	// cout << "[Constrains file loaded]"<<endl;
		//get data from realdata file
		Realdata = getVec3d(realcoordname);
		// cout << "[Real data file loaded]"<<endl;
		for(int i =0; i<3; i++)
			Realfix[i] = Realdata[i];
		// cout << "[Fix loaded]"<<endl;
		//shift the position
		// for(int i=0; i<3; i++)
		// 	Center[i]= getGroupCenter(constrainGroups[i]);
		Center[0]= getGroupCenter(constrainGroups[0]);
		// cout << "[Center get]"<<endl;
		// for(int i=0; i<3;i++)
		// 	Offset[i] = Realfix[i] - Center[i];
		Offset[0] = Realfix[0] - Center[0];
		// cout << "[Real data file loaded]"<<endl;
		shiftMesh(Offset[0]);
		Center[1] = getGroupCenter(constrainGroups[1]);
		Center[2]=getGroupCenter(constrainGroups[2]);
		for(int i=1; i<3;i++)
			Offset[i] = Realfix[i] - Center[i];
		int index;
		for(int i=1; i< 3; i++)
		{
			for(int j=0; j<constrainGroups[i].size(); j++)
			{
				index = constrainGroups[i][j];
				objMesh->setPosition(index, objMesh->getPosition(index)+(Offset[i]*1000.));
			}
		}


		return 1;
	}
void Composite::generateSheet(const char* objMeshname,const char* fixedindex,const char* realcoordname,const std::vector<double>& param){
	updateParam(param);
	// getParameters();
	loadMesh(objMeshname);
	UpdateFixPosition(fixedindex,realcoordname);
	    for(int i=0; i<objMesh->getNumVertices();i++){
      objMesh->setPosition(i,objMesh->getPosition(i)/1000.);
  }
  	// cout << objMesh->getPosition(1)<<endl;
	// cout << "[update done]"<<endl;
	if (clothBWFromObjMesh != NULL)
	    delete clothBWFromObjMesh;
	  clothBWFromObjMesh = new ClothBWFromObjMesh();
	  if (clothBW != NULL)
	   delete clothBW;
	  ClothBW::MaterialGroup material;
	  material.tensileStiffness = tensileStiffness;
	  material.shearStiffness = shearStiffness;
	  material.bendStiffnessU = bendStiffnessU;
	  material.bendStiffnessV = bendStiffnessV;
	  clothBW = clothBWFromObjMesh->GenerateClothBW(objMesh, surfaceDensity, material, 1);
	  clothBW->SetGravity(1, gravityForce);
	  if(clothBWStencilForceModel !=NULL)
	  	delete clothBWStencilForceModel;
	  if(forceModelAssembler != NULL)
	  	delete forceModelAssembler;
	  clothBWStencilForceModel = new ClothBWStencilForceModel(clothBW);
	  forceModelAssembler = new ForceModelAssembler(clothBWStencilForceModel);
	  forceModel = forceModelAssembler; 
	  if(massMatrix != NULL)
	  	delete massMatrix;
	  clothBW->GenerateMassMatrix(&massMatrix);
	  double totalMass = massMatrix->SumEntries() / 3.0;
	  // printf("Total cloth mass: %G\n", totalMass);
	  numVertices = clothBW->GetNumVertices();
	  // cout << "[Vertex number: "<<numVertices<<" ]"<< endl;
	    bool parameters[4]; 
	    parameters[0] = computeStretchShearForce;
	    parameters[1] = computeBendForce;
	    parameters[2] = computeStretchShearStiffness;
	    parameters[3] = computeBendStiffness;
	    // if(parameters[0]&&parameters[1]&&parameters[2]&&parameters[3])
	    // 	cout << "[Computation mode] -Default"<< endl;
	    clothBW->SetComputationMode(parameters);
		clothBW->UseRestAnglesForBendingForces(0);
    	// cout << "[Cloth Generated]"<< endl;
}
void Composite::generateSheet(const char* objMeshname,const float* param){
	if(param!=NULL)
		updateParam(param);
	// getParameters();
	if(meshname == NULL || meshname != objMeshname)
		loadMesh(objMeshname);
	if (clothBWFromObjMesh != NULL)
	    delete clothBWFromObjMesh;
	  clothBWFromObjMesh = new ClothBWFromObjMesh();
	  if (clothBW != NULL)
	   delete clothBW;
	  ClothBW::MaterialGroup material;
	  material.tensileStiffness = tensileStiffness;
	  material.shearStiffness = shearStiffness;
	  material.bendStiffnessU = bendStiffnessU;
	  material.bendStiffnessV = bendStiffnessV;
	  clothBW = clothBWFromObjMesh->GenerateClothBW(objMesh, surfaceDensity, material, 1);
	  clothBW->SetGravity(1, gravityForce);
	  if(clothBWStencilForceModel !=NULL)
	  	delete clothBWStencilForceModel;
	  if(forceModelAssembler != NULL)
	  	delete forceModelAssembler;
	  clothBWStencilForceModel = new ClothBWStencilForceModel(clothBW);
	  forceModelAssembler = new ForceModelAssembler(clothBWStencilForceModel);
	  forceModel = forceModelAssembler; 
	  if(massMatrix != NULL)
	  	delete massMatrix;
	  clothBW->GenerateMassMatrix(&massMatrix);
	  double totalMass = massMatrix->SumEntries() / 3.0;
	  // printf("Total cloth mass: %G\n", totalMass);
	  numVertices = clothBW->GetNumVertices();
	  // cout << "[Vertex number: "<<numVertices<<" ]"<< endl;
	    bool parameters[4]; 
	    parameters[0] = computeStretchShearForce;
	    parameters[1] = computeBendForce;
	    parameters[2] = computeStretchShearStiffness;
	    parameters[3] = computeBendStiffness;
	    // if(parameters[0]&&parameters[1]&&parameters[2]&&parameters[3])
	    // 	cout << "[Computation mode] -Default"<< endl;
	    clothBW->SetComputationMode(parameters);
		clothBW->UseRestAnglesForBendingForces(0);
    	// cout << "[Cloth Generated]"<< endl;
}



void Composite::generateSheet(const char* objMeshname,const vector<double>& param){
	updateParam(param);
	// getParameters();
	if(meshname == NULL || meshname != objMeshname)
		loadMesh(objMeshname);
	if (clothBWFromObjMesh != NULL)
	    delete clothBWFromObjMesh;
	  clothBWFromObjMesh = new ClothBWFromObjMesh();
	  if (clothBW != NULL)
	   delete clothBW;
	  ClothBW::MaterialGroup material;
	  material.tensileStiffness = tensileStiffness;
	  material.shearStiffness = shearStiffness;
	  material.bendStiffnessU = bendStiffnessU;
	  material.bendStiffnessV = bendStiffnessV;
	  clothBW = clothBWFromObjMesh->GenerateClothBW(objMesh, surfaceDensity, material, 1);
	  clothBW->SetGravity(1, gravityForce);
	  if(clothBWStencilForceModel !=NULL)
	  	delete clothBWStencilForceModel;
	  if(forceModelAssembler != NULL)
	  	delete forceModelAssembler;
	  clothBWStencilForceModel = new ClothBWStencilForceModel(clothBW);
	  forceModelAssembler = new ForceModelAssembler(clothBWStencilForceModel);
	  forceModel = forceModelAssembler; 
	  if(massMatrix != NULL)
	  	delete massMatrix;
	  clothBW->GenerateMassMatrix(&massMatrix);
	  double totalMass = massMatrix->SumEntries() / 3.0;
	  // printf("Total cloth mass: %G\n", totalMass);
	  numVertices = clothBW->GetNumVertices();
	  // cout << "[Vertex number: "<<numVertices<<" ]"<< endl;
	    bool parameters[4]; 
	    parameters[0] = computeStretchShearForce;
	    parameters[1] = computeBendForce;
	    parameters[2] = computeStretchShearStiffness;
	    parameters[3] = computeBendStiffness;
	    // if(parameters[0]&&parameters[1]&&parameters[2]&&parameters[3])
	    // 	cout << "[Computation mode] -Default"<< endl;
	    clothBW->SetComputationMode(parameters);
		clothBW->UseRestAnglesForBendingForces(0);
    	// cout << "[Cloth Generated]"<< endl;
}
void Composite::updateConstrain(const std::vector<int>& fix){
	fixedVertices = fix;
	numConstrainedDOFs = 3*fixedVertices.size();
	if (constrainedDOFs)
	    free(constrainedDOFs);
	constrainedDOFs = (int*) malloc (sizeof(int) * numConstrainedDOFs);
	for (int i=0; i<fixedVertices.size(); i++)
	{
	    constrainedDOFs[3*i+0] = (fixedVertices[i]-1) * 3 + 0;
	    constrainedDOFs[3*i+1] = (fixedVertices[i]-1) * 3 + 1;
	    constrainedDOFs[3*i+2] = (fixedVertices[i]-1) * 3 + 2;
	}
	// cout << "[Constrains updated: "<< fixedVertices.size()<<" fixed pts]"<<endl;
	// cout << "[numConstrainedDOFs: "<< numConstrainedDOFs<<"]"<<endl;

}
int Composite::getFixfromfile(const char* filename){
	ifstream fin;
  	fin.open(filename);
	if(!fin.is_open())
	{
	   // cout << "Error opening File: "<<filename<<endl;
	   // cout << "[Cannot open File]"<<endl;
	   return 0;
 	}
 	vector<int> fix;
 	string line;
	while(getline(fin, line)){
		// cout <<line<<endl;
		fix.push_back(stoi(line));
	}
	// cout << "[Constrains file loaded2]"<<endl;
	updateConstrain(fix);
	return 1;
}
void Composite::getData(const double * deformation,const char* objMeshname){
	point pts;
	if (sceneObjDeform != NULL)
    	delete sceneObjDeform;

  	sceneObjDeform = new SceneObjectDeformable(objMeshname);
  	if(!deformdata.empty())
  		deformdata.clear();

	sceneObjDeform->SetVertexDeformations(deformation);
	for(int i=0; i<numVertices; i++)
	{
		sceneObjDeform->GetSingleVertexPositionFromBuffer(i, &pts.x,&pts.y,&pts.z);
		deformdata.push_back(pts);	
	}
	cout << "[Deformation Result Get]"<<endl;
	
}
void Composite::getMarkerData(const double * deformation,const char* objMeshname){
	Vec3d pts;
	Vec3d center;
	if (sceneObjDeform != NULL)
    	delete sceneObjDeform;

  	sceneObjDeform = new SceneObjectDeformable(objMesh);
  	if(!testdata.empty())
  		testdata.clear();
  	
	sceneObjDeform->SetVertexDeformations(deformation);
	// for(int i=0; i<objMesh->getNumVertices();i++){
	// 		objMesh->setPosition(i, objMesh->getPosition(i) + Vec3d(deformation[3 * i + 0], deformation[3 * i + 1], deformation[3 * i + 2]));
	// 	}
	
	for(int i=0; i<90; i++)
	{
		center.set(0);
		for(int j=0; j<markerindex[i].size(); j++)
		{
			sceneObjDeform->GetSingleVertexPositionFromBuffer(markerindex[i][j], &pts[0],&pts[1],&pts[2]);
			// pts = objMesh->getPosition(i);	
			// cout << pts << endl;
			center+=pts;
		}
		center/=markerindex[i].size();
		testdata.push_back(center);	
	}
	// cout << "[Deformation Result Get]"<<endl;
	
}

// void Composite::saveData(){
// 	ofstream myfile;
// 	myfile.open();
// 	for(int i=0 ; i< deformdata.size(); i++)
// 		myfile<<deformdata[i];
// }
void Composite::getSolverInfo(){
	cout << "numVertices: "<<numVertices<<endl;
	cout << "timeStep: "<<timeStep<<endl;
	cout << "numConstrainedDOFs: "<<numConstrainedDOFs<<endl;
	cout << "dampingMass: "<<dampingMass<<endl;
	cout << "dampingStiffness: "<<dampingStiffness<<endl;
	cout << "numSolverThreads: "<<numSolverThreads<<endl;
}
vector<point>& Composite::solve(const char* objMeshname,const std::vector<int>& fixed,const float* param,const int& time){

	passtime tic_toc; 
	generateSheet(objMeshname,param);
	updateConstrain(fixed);
  	if (implicitBackwardEulerSparse != NULL)
  		delete implicitBackwardEulerSparse;
  	implicitBackwardEulerSparse = new ImplicitBackwardEulerSparse(3 * numVertices, timeStep, massMatrix, forceModel, numConstrainedDOFs, constrainedDOFs, dampingMass, dampingStiffness, 1, 1E-5, numSolverThreads);
  	implicitNewmarkSparse = implicitBackwardEulerSparse;
  	integratorBase = implicitNewmarkSparse;
  	if (deform)
	  free(deform);
	if (f_ext)
	  free (f_ext);
	deform = (double*) malloc (sizeof(double) * 3 * numVertices);
	f_ext = (double*) malloc (sizeof(double) * 3 * numVertices);
	for(int i = 0 ; i < 3 * numVertices; i++)
	{
	    deform[i] = 0.0;
	    f_ext[i] = 0.0;
	}
	integratorBase->SetState(deform);
	integratorBase->SetExternalForces(f_ext);
	// cout << "[Solver constructed]"<<endl;
	tic_toc.tic();
	for(int i=0; i<time; i++)
		integratorBase->DoTimestep();
	tic_toc.toc();
	cout << "[TimeStep:]"<< timeStep<<endl;
	memcpy(deform, integratorBase->Getq(), sizeof(double) * 3 * numVertices);
	// cout << "[Displacement Solved]"<<endl;
	getData(deform,objMeshname);
	// cout << "Fisrt data: "<< deformdata[0];
	return deformdata;
  	//generate sheet
  	//construct solver
  	//within given time frame
  	//do time step
  	//return final displacement

}

vector<point>& Composite::solve(const char* objMeshname,const char* fixfilename,const float* param,const int& time){

	passtime tic_toc; 
	generateSheet(objMeshname,param);
	if(!getFixfromfile(fixfilename))
	{
		return deformdata;
	}
  	if (implicitBackwardEulerSparse != NULL)
  		delete implicitBackwardEulerSparse;
  	// cout << "[Solver cleared]"<<endl;
  	// getSolverInfo();
  	implicitBackwardEulerSparse = new ImplicitBackwardEulerSparse(3 * numVertices, timeStep, massMatrix, forceModel, numConstrainedDOFs, constrainedDOFs, dampingMass, dampingStiffness, 1, 1E-5, numSolverThreads);
  	// cout << "[Backward Solver init]"<<endl;
  	implicitNewmarkSparse = implicitBackwardEulerSparse;
  	integratorBase = implicitNewmarkSparse;
  	// cout << "[Solver initialized]"<<endl;
  	if (deform)
	  free(deform);
	if (f_ext)
	  free (f_ext);
	deform = (double*) malloc (sizeof(double) * 3 * numVertices);
	f_ext = (double*) malloc (sizeof(double) * 3 * numVertices);
	for(int i = 0 ; i < 3 * numVertices; i++)
	{
	    deform[i] = 0.0;
	    f_ext[i] = 0.0;
	}
	integratorBase->SetState(deform);
	integratorBase->SetExternalForces(f_ext);
	cout << "[Solver constructed]"<<endl;


	tic_toc.tic();
	for(int i=0; i<time; i++)
		integratorBase->DoTimestep();
	tic_toc.toc();
	cout << "[TimeStep:]"<< timeStep<<endl;
	memcpy(deform, integratorBase->Getq(), sizeof(double) * 3 * numVertices);
	cout << "[Displacement Solved]"<<endl;
	getData(deform,objMeshname);
	cout << "Fisrt data: "<< deformdata[0];
	return deformdata;
}

vector<point>& Composite::solve(const char* objMeshname,const char* fixfilename,const std::vector<double>& param,const int& time){

	passtime tic_toc; 
	generateSheet(objMeshname,param);
	if(!getFixfromfile(fixfilename))
	{
		return deformdata;
	}
  	if (implicitBackwardEulerSparse != NULL)
  		delete implicitBackwardEulerSparse;
  	// cout << "[Solver cleared]"<<endl;
  	// getSolverInfo();
  	implicitBackwardEulerSparse = new ImplicitBackwardEulerSparse(3 * numVertices, timeStep, massMatrix, forceModel, numConstrainedDOFs, constrainedDOFs, dampingMass, dampingStiffness, 1, 1E-5, numSolverThreads);
  	// cout << "[Backward Solver init]"<<endl;
  	implicitNewmarkSparse = implicitBackwardEulerSparse;
  	integratorBase = implicitNewmarkSparse;
  	// cout << "[Solver initialized]"<<endl;
  	if (deform)
	  free(deform);
	if (f_ext)
	  free (f_ext);
	deform = (double*) malloc (sizeof(double) * 3 * numVertices);
	f_ext = (double*) malloc (sizeof(double) * 3 * numVertices);
	for(int i = 0 ; i < 3 * numVertices; i++)
	{
	    deform[i] = 0.0;
	    f_ext[i] = 0.0;
	}
	integratorBase->SetState(deform);
	integratorBase->SetExternalForces(f_ext);
	// cout << "[Solver constructed]"<<endl;


	tic_toc.tic();
	for(int i=0; i<time; i++)
		integratorBase->DoTimestep();
	tic_toc.toc();
	cout << "[TimeStep:]"<< timeStep<<endl;
	memcpy(deform, integratorBase->Getq(), sizeof(double) * 3 * numVertices);
	cout << "[Displacement Solved]"<<endl;
	getData(deform,objMeshname);
	// cout << "Fisrt data: "<< deformdata[0];
	return deformdata;
}

double Composite::getError(){
		double err= 0;
		Vec3d off;
		double length;
		double max = 0;
		for(int i=0, j=3; i<90; i++,j++)
		{	
			off = testdata[i] - Realdata[j];
			length = len(off);
			// cout << length << endl;
			err += length;
			if(length>max)
				max = length;
		}
		err/=90;
		// cout << "max: "<< max<<endl;
		err = err*0.75 + max*0.25;
		return err;

}

vector<Vec3d>& Composite::solvegroup(const char* objMeshname,const char* fixedindex,const char* realcoordname,const std::vector<double>& param,const int& time){

	passtime tic_toc; 
	generateSheet(objMeshname,fixedindex,realcoordname,param);
  	if (implicitBackwardEulerSparse != NULL)
  		delete implicitBackwardEulerSparse;
  	// cout << "[Solver cleared]"<<endl;
  	// getSolverInfo();
  	implicitBackwardEulerSparse = new ImplicitBackwardEulerSparse(3 * numVertices, timeStep, massMatrix, forceModel, numConstrainedDOFs, constrainedDOFs, dampingMass, dampingStiffness, 1, 1E-5, numSolverThreads);
  	// cout << "[Backward Solver init]"<<endl;
  	implicitNewmarkSparse = implicitBackwardEulerSparse;
  	integratorBase = implicitNewmarkSparse;
  	// cout << "[Solver initialized]"<<endl;
  	if (deform)
	  free(deform);
	if (f_ext)
	  free (f_ext);
	deform = (double*) malloc (sizeof(double) * 3 * numVertices);
	f_ext = (double*) malloc (sizeof(double) * 3 * numVertices);
	for(int i = 0 ; i < 3 * numVertices; i++)
	{
	    deform[i] = 0.0;
	    f_ext[i] = 0.0;
	}
	integratorBase->SetState(deform);
	integratorBase->SetExternalForces(f_ext);
	// cout << "[Solver constructed]"<<endl;


	tic_toc.tic();
	for(int i=0; i<time; i++)
		integratorBase->DoTimestep();
	tic_toc.toc();
	cout << "[TimeStep:]"<< timeStep<<endl;
	memcpy(deform, integratorBase->Getq(), sizeof(double) * 3 * numVertices);
	// cout << deform[5]<< endl;
	cout << "[Displacement Solved]"<<endl;
	getMarkerData(deform,objMeshname);
	// cout << "Fisrt data: "<< deformdata[0];
	return testdata;
}

double Composite::solve_err(const char* objMeshname,const char* fixedindex,const char* realcoordname,const std::vector<double>& param,const int& time){

	// passtime tic_toc; 
	generateSheet(objMeshname,fixedindex,realcoordname,param);
  	if (implicitBackwardEulerSparse != NULL)
  		delete implicitBackwardEulerSparse;
  	// cout << "[Solver cleared]"<<endl;
  	// getSolverInfo();
  	implicitBackwardEulerSparse = new ImplicitBackwardEulerSparse(3 * numVertices, timeStep, massMatrix, forceModel, numConstrainedDOFs, constrainedDOFs, dampingMass, dampingStiffness, 1, 1E-5, numSolverThreads);
  	// cout << "[Backward Solver init]"<<endl;
  	implicitNewmarkSparse = implicitBackwardEulerSparse;
  	integratorBase = implicitNewmarkSparse;
  	// cout << "[Solver initialized]"<<endl;
  	if (deform)
	  free(deform);
	if (f_ext)
	  free (f_ext);
	deform = (double*) malloc (sizeof(double) * 3 * numVertices);
	f_ext = (double*) malloc (sizeof(double) * 3 * numVertices);
	for(int i = 0 ; i < 3 * numVertices; i++)
	{
	    deform[i] = 0.0;
	    f_ext[i] = 0.0;
	}
	integratorBase->SetState(deform);
	integratorBase->SetExternalForces(f_ext);
	// cout << "[Solver constructed]"<<endl;


	// tic_toc.tic();
	for(int i=0; i<time; i++)
		integratorBase->DoTimestep();
	// tic_toc.toc();
	// cout << "[TimeStep:]"<< timeStep<<endl;
	memcpy(deform, integratorBase->Getq(), sizeof(double) * 3 * numVertices);
	// cout << "[Displacement Solved]"<<endl;
	getMarkerData(deform,objMeshname);
	// cout << "[Data get]"<<endl;
	// cout << "Fisrt data: "<< deformdata[0];
	return getError();
}