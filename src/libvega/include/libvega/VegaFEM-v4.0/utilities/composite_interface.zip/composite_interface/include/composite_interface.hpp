#ifndef COMPOSITE_INTERFACE_HPP
#define COMPOSITE_INTERFACE_HPP

#include <math.h>
#include <vector>
#include <string>
#include <sstream>
#include "objMesh.h"
#include "clothBWFromObjMesh.h"
#include "clothBWStencilForceModel.h"
#include "forceModelAssembler.h"
#include "implicitNewmarkSparse.h"
#include "implicitBackwardEulerSparse.h"
#include "sceneObjectDeformable.h"
#include "minivector.h"
#include <stack>
#include <ctime>
// #include "constrainedDOFs.h"
#include <fstream>
#include <iostream>

// inline void parseData(const char* filename, std::vector<Vec3d>& fixed, std::vector<Vec3d>& point, const int& ifCenter=1);
// inline void parseInitData(const char* filename, const ObjMesh* obj, std::vector<int>& init_marker, const int& ifCenter=1);
// inline void parseTrainingData(const char* filename, const ObjMesh* obj, std::vector<Vec3d>& training_fix, 
// 								std::vector<Vec3d>& training_marker, std::vector<int>& fixgroups, const int& ifCenter=1);
// inline void shift(ObjMesh* obj, const std::vector<Vec3d>& fixed, std::vector<int>* groups, Vec3d* fvect);

// inline Vec3d& groupCenter(ObjMesh* obj, const std::vector<Vec3d>& group);

// struct point{
// double x,y,z;
// 	friend std::ostream& operator << (std::ostream& out, const point& pt)
// 	{
// 		out << "["<<pt.x<<", "<<pt.y<<", " << pt.z<< "]"<< std::endl;
// 		return out;
// 	};
// 	friend std::ofstream& operator << (std::ofstream& fout, const point& pt)
// 	{
// 		fout <<pt.x<<","<<pt.y<<"," << pt.z<< std::endl;
// 		return fout;
// 	};
// 	friend point operator + (const  point& p1,const point& p2)
// 	{
// 		point result;
// 		result.x= p1.x+p2.x;
// 		result.y= p1.y+p2.y;
// 		result.z= p1.z+p2.z;
// 		return result;
// 	};
// 	friend point operator - (const point& p1,const point& p2)
// 	{
// 		point result;
// 		result.x= p1.x-p2.x;
// 		result.y= p1.y-p2.y;
// 		result.z= p1.z-p2.z;
// 		return result;
// 	};
// 	double length()
// 	{
// 		return sqrt( x*x+y*y+z*z );
// 	}
// 	double length(point& pt2)
// 	{
// 		return sqrt( (x-pt2.x)*(x-pt2.x)+
// 					(y-pt2.y)*(y-pt2.y)+
// 					(z-pt2.z)*(z-pt2.z) );
// 	}
// 	std::vector<point> loadpts(const char* name, const int offset)
// 	{
// 		std::fstream fin;
// 		fin.open(name);
// 		std::string line;
// 		std::vector<std::string> coord;
// 		std::string value;
// 		std::vector<point> data;
// 		point pts;
// 		data.clear();
// 		int count=0;
// 		while(getline(fin,line)){
// 			if(count >= offset)
// 			{
// 				std::stringstream ss(line);
// 				coord.clear();
// 				while(getline(ss,value,',')){
// 					coord.push_back(value);
// 				}
// 				pts.x=stod(coord[0]);
// 				pts.y=stod(coord[1]);
// 				pts.z=stod(coord[2]);
// 				data.push_back(pts);
// 			}
// 			count++;
// 		}
// 		std::cout <<"[ "<< data .size() <<" data points loaded]\n";
// 		return data;	
// 	}

// };

struct passtime{
	std::stack<clock_t> tictoc_stack;
	double diff;
	void tic() {
    tictoc_stack.push(clock());
	}

	void toc() {
		diff = (((double)(clock() - tictoc_stack.top())) / CLOCKS_PER_SEC)/5.;
    std::cout << "[Time elapsed(sec)]: "
              << diff
              << std::endl;

    tictoc_stack.pop();
	}
	// double get(){return diff;}
};

class Composite
{
private:
    static bool instanceFlag;
    static Composite *sheet;
    
    //Physics Parameters
    //The one that will be updated from ML 
    float dampingMass;
	float dampingStiffness;
	float surfaceDensity;
	float tensileStiffness;
	float shearStiffness;
	float bendStiffnessU;
	float bendStiffnessV;
	//Const Parameters
	const float gravityForce=9.81;//9.81
	//Simulation and Calculation Parameters
	
	//Computation parameters (default to computing everything)
	int computeStretchShearForce, computeStretchShearStiffness, computeBendForce, computeBendStiffness;
	int numInternalForceThreads; // default = 0 (not multi-threaded)
	
	//solver parameters
	int numVertices=0;
	float timeStep=0.05;
	SparseMatrix * massMatrix;
	ForceModel * forceModel;
	int numConstrainedDOFs = 0; 
	int * constrainedDOFs = NULL;
	int numSolverThreads=2; // default = 0 (not multi-threaded)
	//Deformation Parameters
	double* deform = NULL;
	double* f_ext = NULL;
	//Model objects
	const char* meshname;
	ClothBW * clothBW;
	SceneObjectDeformable * sceneObjDeform;
	ClothBWStencilForceModel * clothBWStencilForceModel;
	ForceModelAssembler * forceModelAssembler;
	ObjMesh * objMesh;
	ClothBWFromObjMesh * clothBWFromObjMesh;
	IntegratorBase * integratorBase;
	ImplicitNewmarkSparse * implicitNewmarkSparse;
	ImplicitBackwardEulerSparse * implicitBackwardEulerSparse;
	double avg_err = 0;
	double opt_err = 0;
	double max_err = 0;
	double min_err = 100;
	double std_err = 0;
	std::vector<Vec3d> training_marker;
	std::vector<int> fixGroups;
	
	Composite();

public:
    static Composite* getInstance();
    static void ResetInstance(){
    	delete sheet;
    	sheet = NULL;
    };
    //sets time step
    void setTimeStep(const float& step){timeStep = step;};
    void setDensity(const float& dens){surfaceDensity = dens;};
    //Updates parameter to the solver
    //@param mechanical behavior of the sheet
    void updateParam(const float* param);
    void updateParam(const std::vector<double>& param);
    //loadMesh 
    //Construct ObjMesh object and parse all scanned data to destinate location 
    //@objMeshname mesh file name
    //@init_data initial state of scanned data
    //@training_data draping state of scanned data
    void loadMesh(const char* objMeshname, const char* training_data);
    void updateConfig(const char* objMeshname, const char* robot_data);
    //generateSheet
    //Constructs the clothBW class for the solver
    void generateSheet();
    //Use the fixed poisiton of training data as constrain 
    void updateConstrain();
    //construct integrater solver
    double solve_err(const char* objMeshname,const char* training_data,const std::vector<double>& param,const int& time=100);
    //err_type 0 for average err, 1 for weighted_err, 2 for std_err, 3 for maximum err, 4 for min_err 
    double show_err(const char* objMeshname,const char* training_data,const std::vector<double>& param,const int& time=100,const int& err_type=0);
    double* solve_config(const char* objMeshname,const char* robot_data,const int& time=10);
	//Error is defined as 0.5*offset + 0.5* maximum offset
    //Need to be used after solve_err()
    double getError();
    
    /////Data retrieve methods/////////
    void getParameters();
    void getSolverInfo();
    inline SceneObjectDeformable * getSceneObj(){return sceneObjDeform;}
    inline ClothBW * getClothBW(){return clothBW;}
    inline std::vector<int>& getFixedGroups(){return fixGroups;}
    inline double* getDeform(){return deform;}
    inline float& getTimeStep(){return timeStep;}
    inline ImplicitNewmarkSparse * getImplicitNewmarkSparse(){return implicitNewmarkSparse;}
    inline IntegratorBase * getIntegratorBase(){return integratorBase;}
    ~Composite()
    {
    	if (implicitBackwardEulerSparse != NULL)
	    	delete implicitBackwardEulerSparse;
	  
	  if (clothBW != NULL)
	    delete clothBW;

	  if (clothBWFromObjMesh != NULL)
	    delete clothBWFromObjMesh;
	  
	  // render objs
	  if (objMesh != NULL)
	    delete objMesh;

	  if (sceneObjDeform != NULL)
	    delete sceneObjDeform;
	  instanceFlag = false;
	  
	  std::cout <<"sheet clear\n";

    }
};

//TODO: parse training points
//      save them into fixed points and mesh point
//void parseTrainingData(filename, &fixedpoints, &meshpoints)
//save as vector<Vec3d>

inline void parseData(const char* filename, std::vector<Vec3d>& fixed, std::vector<Vec3d>& point, const int& ifCenter){
		std::fstream fin;
	  	fin.open(filename);
		if(!fin.is_open()){
			std::cout<<"open failed"<<std::endl;
		}
		std::string name(filename);
		int fix_number = filename[113]-'0';
		// std::cout <<"fix:" <<fix_number<<std::endl;
		fix_number*=4;
		std::string line;
		std::vector<std::string> coord;
		std::string value;
		// int count=0;
		int i=0;
		if(fixed.size()!=0)
			fixed.clear();
		if(point.size()!=0)
			point.clear();
		while(getline(fin,line)){
				std::stringstream ss(line);
				coord.clear();
				while(getline(ss,value,',')){
					coord.push_back(value);
				}

				if(i>ifCenter-1 && i<fix_number+ifCenter)
					fixed.push_back(Vec3d(stod(coord[0]),stod(coord[1]),stod(coord[2])));
				else if(i>ifCenter-1)
					point.push_back(Vec3d(stod(coord[0]),stod(coord[1]),stod(coord[2])));
				i++;
		}
}

inline void parseData(const char* filename, std::vector<Vec3d>& fixed){
		std::fstream fin;
	  	fin.open(filename);
		if(!fin.is_open()){
			std::cout<<"open failed"<<std::endl;
		}
		
		// int fix_number = filename[113]-'0';
		// std::cout <<"fix:" <<fix_number<<std::endl;
		// fix_number*=4;
		std::string line;
		std::vector<std::string> coord;
		std::string value;
		// int count=0;
		
		if(fixed.size()!=0)
			fixed.clear();

		while(getline(fin,line)){
				std::stringstream ss(line);
				coord.clear();
				while(getline(ss,value,',')){
					coord.push_back(value);
				}

					fixed.push_back(Vec3d(stod(coord[0]),stod(coord[1]),stod(coord[2])));
				
		}
}







inline Vec3d groupCenter(ObjMesh* obj, const std::vector<int>& group){

	Vec3d center(0,0,0);
		
		for(int j= 0; j<group.size(); j++){
			center+=obj->getPosition(group[j]);
		}
		center/=group.size();
	return center;
}

inline Vec3d groupCenter(SceneObjectDeformable* obj, const std::vector<int>& group){
	Vec3d center(0,0,0);
	for(int j=0; j<group.size(); j++)
	{
		center+=obj->GetSingleVertexPositionFromBuffer(group[j]);
	}
	center/=group.size();
	return center;
}

inline void parseTrainingData(const char* filename, const ObjMesh* obj, std::vector<Vec3d>& training_fix, 
								std::vector<Vec3d>& training_marker, std::vector<int>& fixgroups, const int& ifCenter){

	parseData(filename, training_fix, training_marker, ifCenter);
	for(int i=0; i< training_fix.size(); i++)
		fixgroups.push_back(obj->getClosestVertex(training_fix[i]));
	std::sort(fixgroups.begin(), fixgroups.end());

}


inline void parseInitData(const char* filename, const ObjMesh* obj, std::vector<int>& init_marker, const int& ifCenter){
	std::vector<Vec3d> init_fix;
	std::vector<Vec3d> init_marker_point;
	parseData(filename, init_fix, init_marker_point, ifCenter);
	
	for(int i=0; i< init_marker_point.size(); i++)
		init_marker.push_back(obj->getClosestVertex(init_marker_point[i]));
	// std::sort(init_marker.begin(), init_marker.end());

}

inline void parseRobotData(const char* filename, const ObjMesh* obj, std::vector<Vec3d>& fix_location, 
								std::vector<int>& fixgroups){

	parseData(filename, fix_location);
	for(int i=0; i< fix_location.size(); i++)
		fixgroups.push_back(obj->getClosestVertex(fix_location[i]));
	std::sort(fixgroups.begin(), fixgroups.end());

}

#endif