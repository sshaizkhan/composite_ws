# Physics Parameters
+ dampingMass
+ damingStiffness
+ surfaceDensity
+ tensileStiffness
+ shearStiffness
+ bendStiffnessU
+ bendStiffnessV

# Const. parameters
+ gravityForce

# Simulation Paramters
+ timeStep

# Computation Parameters
+ computeStretchShearForce, computeStretchShearStiffness, computeBendForce, computeBendStiffness  
+ numInternalForceThreads
+ numSolverThreads

# Output Parameters
+ u (records current deformation)
+ f_ext (records current external force)

# Model Objects
>	ClothBW * clothBW = NULL;
>	ClothBWStencilForceModel * clothBWStencilForceModel = NULL;
>	ForceModelAssembler * forceModelAssembler = NULL;
>	ObjMesh * objMesh = NULL;
>	ClothBWFromObjMesh * clothBWFromObjMesh = NULL;

# Solver Object
>	IntegratorBase * integratorBase = NULL;
>	ImplicitNewmarkSparse * implicitNewmarkSparse = NULL;
>	ImplicitBackwardEulerSparse * implicitBackwardEulerSparse = NULL;
>	ForceModel * forceModel = NULL;
>	SparseMatrix * massMatrix = NULL;

# initScene()
	I need to turn the following segments into one function that can be called from a defined library/header 
	In the simulator, this function is called everytime when a **new set** of parameters are updated.
### load OBJ Mesh
>	  if (objMesh != NULL)
>	    delete objMesh;
>	  objMesh = new ObjMesh(objMeshname);

### declare clothBWFromObjMesh
>	  if (clothBWFromObjMesh != NULL)
>	    delete clothBWFromObjMesh;
>	  clothBWFromObjMesh = new ClothBWFromObjMesh();

### Add in physical parameters
>	  if (clothBW != NULL)
>	   delete clothBW;
>	  ClothBW::MaterialGroup material;
>	  material.tensileStiffness = tensileStiffness;
>	  material.shearStiffness = shearStiffness;
>	  material.bendStiffnessU = bendStiffnessU;
>	  material.bendStiffnessV = bendStiffnessV;
>	  clothBW = clothBWFromObjMesh->GenerateClothBW(objMesh, surfaceDensity, material, addGravity);
>	  clothBW->SetGravity(addGravity, gravityForce);

### Construct Force models
>	  clothBWStencilForceModel = new ClothBWStencilForceModel(clothBW);
>	  forceModelAssembler = new ForceModelAssembler(clothBWStencilForceModel);
>	  forceModel = forceModelAssembler; 
>	  SparseMatrix * massMatrix;
>	  clothBW->GenerateMassMatrix(&massMatrix);
>	  double totalMass = massMatrix->SumEntries() / 3.0;
>	  printf("Total cloth mass: %G\n", totalMass);

### Add fixed points
	  numConstrainedDOFs = 3*numFixedVertices;
	  if (constrainedDOFs)
	    free(constrainedDOFs);
	  constrainedDOFs = (int*) malloc (sizeof(int) * numConstrainedDOFs);
	  for (int i=0; i<numFixedVertices; i++)
	  {
	    constrainedDOFs[3*i+0] = fixedVertices[i] * 3 + 0;
	    constrainedDOFs[3*i+1] = fixedVertices[i] * 3 + 1;
	    constrainedDOFs[3*i+2] = fixedVertices[i] * 3 + 2;
	  }

### Construct Solver
	  int numVertices = clothBW->GetNumVertices(); 
	  if (implicitBackwardEulerSparse != NULL)
	  delete implicitBackwardEulerSparse;
	  implicitBackwardEulerSparse = new ImplicitBackwardEulerSparse(3 * numVertices, timeStep, massMatrix, forceModel, numConstrainedDOFs, constrainedDOFs, dampingMass, dampingStiffness, 1, 1E-5, numSolverThreads);
	  implicitNewmarkSparse = implicitBackwardEulerSparse;
	  integratorBase = implicitNewmarkSparse;

### Set Solver data
	  if (u)
	    free(u);
	  if (f_ext)
	    free (f_ext);
	  u = (double*) malloc (sizeof(double) * 3 * numVertices);
	  f_ext = (double*) malloc (sizeof(double) * 3 * numVertices);
	  for(int i = 0 ; i < 3 * numVertices; i++)
	  {
	    u[i] = 0.0;
	    f_ext[i] = 0.0;
	  }
	  integratorBase->SetState(u);
	  integratorBase->SetExternalForces(f_ext);

# initGUI()
By looking at this function, one can know how to update a set of parameter

	  glui->add_edittext_to_panel(scene_option_panel,"tensileStiffness",GLUI_EDITTEXT_FLOAT,&tensileStiffness);
	  glui->add_edittext_to_panel(scene_option_panel,"shearStiffness",GLUI_EDITTEXT_FLOAT,&shearStiffness);
	  glui->add_edittext_to_panel(scene_option_panel,"bendStiffnessU",GLUI_EDITTEXT_FLOAT,&bendStiffnessU);
	  glui->add_edittext_to_panel(scene_option_panel,"bendStiffnessV",GLUI_EDITTEXT_FLOAT,&bendStiffnessV);
	  glui->add_edittext_to_panel(scene_option_panel,"dampingMass",GLUI_EDITTEXT_FLOAT,&dampingMass);
	  glui->add_edittext_to_panel(scene_option_panel,"dampingStiffness",GLUI_EDITTEXT_FLOAT,&dampingStiffness);
	  glui->add_edittext_to_panel(scene_option_panel,"gravityForce",GLUI_EDITTEXT_FLOAT,&gravityForce);
	  glui->add_edittext_to_panel(scene_option_panel,"mousePower",GLUI_EDITTEXT_FLOAT,&mouseForceCoeff);
	  glui->add_checkbox_to_panel(scene_option_panel,"useRestAngles", &useRestAngles);
	  glui->add_button_to_panel(scene_option_panel,"Upload Parameters",0, update_simulation_status);

To update the timestep 
>	integratorBase->SetTimestep(timeStep);
# OpenGL interface

### displayFunction
The deformation info is **set** by
>	sceneObjDeform->SetVertexDeformations(u);
The Vertex info is **get** by
>       sceneObjDeform->GetSingleVertexRestPosition(fixedVertices[i],
            &fixedVertexPos[0], &fixedVertexPos[1], &fixedVertexPos[2]);

### idleFunction
During simulation(runSimulation ==1), the external force was updated if a vertex is **dragged or wind is applied**.
>	integratorBase->AddExternalForces(f_ext);
Adding force/stiffness matrix toggling ability, set computation mode for the model
    bool parameters[4]; 
    parameters[0] = computeStretchShearForce;
    parameters[1] = computeBendForce;
    parameters[2] = computeStretchShearStiffness;
    parameters[3] = computeBendStiffness;
    
    clothBW->SetComputationMode(parameters);
    clothBW->UseRestAnglesForBendingForces(useRestAngles);

Updating all Force 
>	integratorBase->DoTimestep(); // the big timestep

Retrieve the displacement change
>	memcpy(u, integratorBase->Getq(), sizeof(double) * 3 * n);

# Interaction features
+ initGUI  
+ mouseMotion  
+ mouseButtonActivityFunction  
+ mouseMotionFunction  

#Update Restposition for multiple fixed dataset
>	#include "minivector.h"

>	vec3d* Composite::getVec3d(const char* realdataname){
		fstream fin;
	  	fin.open(realdataname);
		if(!fin.is_open())
			return vec3d(0,0,0);
		std::string line;
		std::vector<std::string> coord;
		std::string value;
		vec3d data[3];
		int count=0;
		int i=0;
		while(getline(fin,line)){
				std::stringstream ss(line);
				coord.clear();
				while(getline(ss,value,',')){
					coord.push_back(value);
				}
				data[i] = vec3d(coord[0],coord[1],coord[2]);
				i++;
		}
		return data;
	}

>	void Composite::shiftMesh(const vec3d& offset){
		for(int i=0; i<objMesh->getNumVertices();i++){
			objMesh->setPosition(i,objMesh->getPosition(i)+offset);
		}
	}

>	int Composite::UpdateFixPosition(const char* indexfilename, const char* realdataname){
		//read the file
		ifstream fin;
	  	fin.open(indexfilename);
		if(!fin.is_open())
			return 0;
	 	

	 	//make them into groups
	 	std::vector<int> constrainGroups[3];
	 	vec3d Realfix[3];
	 	vec3d Offset[3];
	 	vec3d Center[3];
	 	Center[0] = vec3d(0,0,0);
	 	Center[1] = vec3d(0,0,0);
	 	Center[2] = vec3d(0,0,0);
	 	vector<int> fix;
	 	int groupsize[3]={4,4,4};
	 	string line;
	 	int count = 0;
	 	int i=0;
		while(getline(fin, line)){
			// cout <<line<<endl;
			if(count >= groupsize[i])
			{
				i++;
				count = 0;
			}
			constrainGroups[i].push_back(stoi(line));
			Center[i]+=objMesh->getPosition(stoi(line));
			fix.push_back(stoi(line));
			count++;
		}
		updateConstrain(fix);
		free(fix);
		// cout << "[Constrains file loaded]"<<endl;


		//get data from realdata file
		Realfix = getVec3d(realdataname);
		//shift the position
		for(int i=0; i<3; i++)
			Center[i]/=groupsize[i];
		for(int i=0; i<3;i++)
			Offset[i] = Realfix[i] - Center[i];
		shiftMesh(Offset[0]);
		int index;
		for(int i=1; i< 3; i++)
		{
			for(int j=0; j<constrainGroups[i].size(); j++)
			{
				index = constrainGroups[i][j]
				objMesh->setPosition(index, getPosition(index)+Offset[i]);
			}
		}
		return 1;
	}



objMesh->setPosition(int index, Vec3d & position);
objMesh->setPosition(int index, Vec3d & position);
objMesh->setPosition(int index, Vec3d & position);
clothBW = clothBWFromObjMesh->GenerateClothBW(objMesh, surfaceDensity, material, 1);
>	numVertices = clothBW->GetNumVertices();
>	restPositions = clothBW->GetRestPositions();
masses.data() = clothBW->GetNumVertices();
>	numTriangles = clothBW->GetNumTriangles();
>	triangles = clothBW->GetTriangles();
triangleGroups = clothBW->GetNumVertices();
numGroups = clothBW->GetNumVertices();
material = clothBW->GetNumVertices();
addGravity = clothBW->GetNumVertices();

