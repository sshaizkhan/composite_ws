#include "composite_interface.hpp"
#include "sceneObjectDeformable.h"
#include "performanceCounter.h"
#include <iostream>
#include "configFile.h"
#include "listIO.h"
#include <string>

using namespace std;

bool Composite::instanceFlag = false;
Composite* Composite::sheet = NULL;

Composite::Composite():dampingMass(0.02),
dampingStiffness(0.03),surfaceDensity(0.04),
tensileStiffness(8500.0), shearStiffness(100.0),
bendStiffnessU(0.06),bendStiffnessV(0.06),
clothBW(NULL),sceneObjDeform(NULL), clothBWStencilForceModel(NULL),
forceModelAssembler(NULL),objMesh(NULL),
clothBWFromObjMesh(NULL),integratorBase(NULL),
implicitNewmarkSparse(NULL),implicitBackwardEulerSparse(NULL),meshname(NULL),
forceModel(NULL),massMatrix(NULL),computeStretchShearForce(1),computeStretchShearStiffness(1),computeBendForce(1),computeBendStiffness(1)
{

}
Composite* Composite::getInstance()
{
	if(!instanceFlag)
	{
		sheet = new Composite;
		instanceFlag= true;
	}
	return sheet;
}

void Composite::getParameters(){
	cout << "dampingMass: "<<dampingMass<<endl;
	cout << "dampingStiffness: "<<dampingStiffness<<endl;
	cout << "surfaceDensity: "<<surfaceDensity<<endl;
	cout << "tensileStiffness: "<<tensileStiffness<<endl;
	cout << "shearStiffness: "<<shearStiffness<<endl;
	cout << "bendStiffnessU: "<<bendStiffnessU<<endl;
	cout << "bendStiffnessV: "<<bendStiffnessV<<endl;
}
void Composite::updateParam(const float* p){
	tensileStiffness = p[0];
	shearStiffness = p[1];
	bendStiffnessU = p[2];
	bendStiffnessV = p[2];
	dampingMass = 0.0;
	dampingStiffness = 0.1;
	// surfaceDensity = p[0];
	// tensileStiffness = p[1];
	// shearStiffness = p[2];
	// bendStiffnessU = p[3];
	// bendStiffnessV = p[4];
	// dampingMass = p[5];
	// dampingStiffness = p[6];
	// cout << "[Parameters updated]"<< endl;
}
void Composite::updateParam(const vector<double>& p){
	tensileStiffness = p[0];
	shearStiffness = p[1];
	bendStiffnessU = p[2];
	bendStiffnessV = p[2];
	dampingMass = 0.0;
	dampingStiffness = 0.1;
	// 	surfaceDensity = p[0];
	// tensileStiffness = p[1];
	// shearStiffness = p[2];
	// bendStiffnessU = p[3];
	// bendStiffnessV = p[4];
	// dampingMass = p[5];
	// dampingStiffness = p[6];
	// cout << "[Parameters updated: "<< p[0]<<" "<< p[1]<<" "<< p[2]<<" "<< p[3]<<" "<< p[4]<<" "<< p[5]<<" "<< p[6]<<"]" <<endl;
}

// void Composite::setTimeStep(const float& step){
// 	timeStep = step;
// }

void Composite::loadMesh(const char* objMeshname, const char* training_data){
	if (objMesh != NULL)	
	    delete objMesh;
	  objMesh = new ObjMesh(objMeshname);
    for(int i=0; i<objMesh->getNumVertices();i++)
      objMesh->setPosition(i,objMesh->getPosition(i)/1000.);
  	if(training_marker.size() != 0)
  		training_marker.clear();
  	if(fixGroups.size() != 0)
  		fixGroups.clear();
  	// if(init_marker.size() != 0)
  	// 	init_marker.clear();
  	std::vector<Vec3d> training_fixed;
  	
  	parseTrainingData(training_data, objMesh, training_fixed, training_marker, fixGroups, 1);
  	updateConstrain();

}
void Composite::updateConfig(const char* objMeshname, const char* robot_data){
	if (objMesh != NULL)	
	    delete objMesh;
	  objMesh = new ObjMesh(objMeshname);
    for(int i=0; i<objMesh->getNumVertices();i++)
      objMesh->setPosition(i,objMesh->getPosition(i)/1000.);
  	if(training_marker.size() != 0)
  		training_marker.clear();
  	if(fixGroups.size() != 0)
  		fixGroups.clear();
  	// if(init_marker.size() != 0)
  	// 	init_marker.clear();
  	std::vector<Vec3d> training_fixed;
  	parseRobotData(robot_data,objMesh, training_fixed,fixGroups);
  	updateConstrain();

}
void Composite::generateSheet(){

	if (clothBWFromObjMesh != NULL)
	    delete clothBWFromObjMesh;
	  clothBWFromObjMesh = new ClothBWFromObjMesh();
	  if (clothBW != NULL)
	   delete clothBW;
	// getParameters();
	  ClothBW::MaterialGroup material;
	  material.tensileStiffness = tensileStiffness;
	  material.shearStiffness = shearStiffness;
	  material.bendStiffnessU = bendStiffnessU;
	  material.bendStiffnessV = bendStiffnessV;
	  clothBW = clothBWFromObjMesh->GenerateClothBW(objMesh, surfaceDensity, material, 1);
	  clothBW->SetGravity(1, gravityForce);
	  // if(clothBWStencilForceModel !=NULL)
	  // 	delete clothBWStencilForceModel;
	  // if(forceModelAssembler != NULL)
	  // 	delete forceModelAssembler;
	  clothBWStencilForceModel = new ClothBWStencilForceModel(clothBW);
	  forceModelAssembler = new ForceModelAssembler(clothBWStencilForceModel);
	  forceModel = forceModelAssembler; 
	  if(massMatrix != NULL)
	  	delete massMatrix;
	  clothBW->GenerateMassMatrix(&massMatrix);
	  // double totalMass = massMatrix->SumEntries() / 3.0;
	  // printf("Total cloth mass: %G\n", totalMass);
	  numVertices = clothBW->GetNumVertices();
	  // cout << "[Vertex number: "<<numVertices<<" ]"<< endl;
	 //    bool parameters[4]; 
	 //    parameters[0] = computeStretchShearForce;
	 //    parameters[1] = computeBendForce;
	 //    parameters[2] = computeStretchShearStiffness;
	 //    parameters[3] = computeBendStiffness;
	 //    // if(parameters[0]&&parameters[1]&&parameters[2]&&parameters[3])
	 //    // 	cout << "[Computation mode] -Default"<< endl;
	 //    clothBW->SetComputationMode(parameters);
		// clothBW->UseRestAnglesForBendingForces(0);
    	// cout << "[Cloth Generated]"<< endl;
}

void Composite::updateConstrain(){
 int numFixedVertices = fixGroups.size();
  // cout << "numFixedVertices: "<< numFixedVertices << endl;
  
  numConstrainedDOFs = 3*numFixedVertices;
  if (constrainedDOFs)
    free(constrainedDOFs);
  constrainedDOFs = (int*) malloc (sizeof(int) * numConstrainedDOFs);
  for (int i=0; i<numFixedVertices; i++)
  {
    constrainedDOFs[3*i+0] = fixGroups[i] * 3 + 0;
    constrainedDOFs[3*i+1] = fixGroups[i] * 3 + 1;
    constrainedDOFs[3*i+2] = fixGroups[i] * 3 + 2;
  }

}

double Composite::getError(){
	memcpy(deform, integratorBase->Getq(), sizeof(double) * 3 * numVertices);
	if (sceneObjDeform != NULL)
    	delete sceneObjDeform;

  	sceneObjDeform = new SceneObjectDeformable(objMesh);

	sceneObjDeform->SetVertexDeformations(deform);
	
	// Vec3d offset;
	double err = 0;
	double max = 0;
	double* distPTR = new double(10);
	for(int i=0; i<training_marker.size(); i++){
		sceneObjDeform->GetClosestVertex(training_marker[i],distPTR);
		
		if(*distPTR>max)
		    max = *distPTR;
		err+=*distPTR; 
	}
	err/= training_marker.size();
	// std::cout << "err: "<<err<<std::endl;
	delete distPTR;
	return (err*0.2+max*0.8);

}

// void Composite::saveData(){
// 	ofstream myfile;
// 	myfile.open();
// 	for(int i=0 ; i< deformdata.size(); i++)
// 		myfile<<deformdata[i];
// }
void Composite::getSolverInfo(){
	cout << "numVertices: "<<numVertices<<endl;
	cout << "timeStep: "<<timeStep<<endl;
	cout << "numConstrainedDOFs: "<<numConstrainedDOFs<<endl;
	cout << "dampingMass: "<<dampingMass<<endl;
	cout << "dampingStiffness: "<<dampingStiffness<<endl;
	cout << "numSolverThreads: "<<numSolverThreads<<endl;
}


double Composite::solve_err(const char* objMeshname,const char* training_data,const std::vector<double>& param,const int& time){

	// passtime tic_toc; 
	updateParam(param);
	// getParameters();
	loadMesh(objMeshname, training_data);
	generateSheet();
	// cout << "[sheet constructed]"<<endl;
  	if (implicitBackwardEulerSparse != NULL)
  		delete implicitBackwardEulerSparse;
  	// cout << "[Solver cleared]"<<endl;
  	// getSolverInfo();
  	implicitBackwardEulerSparse = new ImplicitBackwardEulerSparse(3 * numVertices, timeStep, massMatrix, forceModel, numConstrainedDOFs, constrainedDOFs, dampingMass, dampingStiffness, 1, 1E-5, numSolverThreads);
  	// cout << "[Backward Solver init]"<<endl;
  	implicitNewmarkSparse = implicitBackwardEulerSparse;
  	integratorBase = implicitNewmarkSparse;
  	// cout << "[Solver initialized]"<<endl;
  	if (deform)
	  free(deform);
	if (f_ext)
	  free (f_ext);
	deform = (double*) malloc (sizeof(double) * 3 * numVertices);
	f_ext = (double*) malloc (sizeof(double) * 3 * numVertices);
	for(int i = 0 ; i < 3 * numVertices; i++)
	{
	    deform[i] = 0.0;
	    f_ext[i] = 0.0;
	}
	integratorBase->SetState(deform);
	integratorBase->SetExternalForces(f_ext);
	// cout << "[Solver constructed]"<<endl;


	// tic_toc.tic();
	for(int i=0; i<time; i++)
		integratorBase->DoTimestep();
	// tic_toc.toc();
	// cout << "[TimeStep:]"<< timeStep<<endl;

	memcpy(deform, integratorBase->Getq(), sizeof(double) * 3 * numVertices);
	if (sceneObjDeform != NULL)
    	delete sceneObjDeform;

  	sceneObjDeform = new SceneObjectDeformable(objMesh);

	sceneObjDeform->SetVertexDeformations(deform);
	
	// Vec3d offset;
	double err = 0;
	double max = 0;
	double* distPTR = new double(10);
	for(int i=0; i<training_marker.size(); i++){
		sceneObjDeform->GetClosestVertex(training_marker[i],distPTR);
		if(*distPTR==0)
			*distPTR=0.1;
		if(*distPTR>max)
		    max = *distPTR;

		err+=*distPTR; 
	}
	err/= training_marker.size();
	// std::cout << "err: "<<err<<std::endl;
	delete distPTR;
	return (err*1+max*0.5);
	// return getError();
}

double Composite::show_err(const char* objMeshname,const char* training_data,const std::vector<double>& param,const int& time, const int& err_type){

	// passtime tic_toc; 
	updateParam(param);
	// getParameters();
	loadMesh(objMeshname, training_data);
	generateSheet();
	// cout << "[sheet constructed]"<<endl;
  	if (implicitBackwardEulerSparse != NULL)
  		delete implicitBackwardEulerSparse;
  	// cout << "[Solver cleared]"<<endl;
  	// getSolverInfo();
  	implicitBackwardEulerSparse = new ImplicitBackwardEulerSparse(3 * numVertices, timeStep, massMatrix, forceModel, numConstrainedDOFs, constrainedDOFs, dampingMass, dampingStiffness, 1, 1E-5, numSolverThreads);
  	// cout << "[Backward Solver init]"<<endl;
  	implicitNewmarkSparse = implicitBackwardEulerSparse;
  	integratorBase = implicitNewmarkSparse;
  	// cout << "[Solver initialized]"<<endl;
  	if (deform)
	  free(deform);
	if (f_ext)
	  free (f_ext);
	deform = (double*) malloc (sizeof(double) * 3 * numVertices);
	f_ext = (double*) malloc (sizeof(double) * 3 * numVertices);
	for(int i = 0 ; i < 3 * numVertices; i++)
	{
	    deform[i] = 0.0;
	    f_ext[i] = 0.0;
	}
	integratorBase->SetState(deform);
	integratorBase->SetExternalForces(f_ext);
	// cout << "[Solver constructed]"<<endl;


	// tic_toc.tic();
	for(int i=0; i<time; i++)
		integratorBase->DoTimestep();
	// tic_toc.toc();
	// cout << "[TimeStep:]"<< timeStep<<endl;

	memcpy(deform, integratorBase->Getq(), sizeof(double) * 3 * numVertices);
	if (sceneObjDeform != NULL)
    	delete sceneObjDeform;

  	sceneObjDeform = new SceneObjectDeformable(objMesh);

	sceneObjDeform->SetVertexDeformations(deform);
	
	// Vec3d offset;
	double* distPTR = new double(10);
	avg_err=0;
	max_err=0;
	min_err=0;
	std::vector<double> pts;
	for(int i=0; i<training_marker.size(); i++){
		sceneObjDeform->GetClosestVertex(training_marker[i],distPTR);
		if(*distPTR==0)
			*distPTR=0.1;
		if(*distPTR>max_err)
		    max_err = *distPTR;
		if(*distPTR<min_err)
			min_err = *distPTR;
		avg_err+=*distPTR; 
		pts.push_back(*distPTR);
	}
	avg_err/= training_marker.size();
	
	for(int i=0; i<pts.size(); i++)
	{
		std_err += pow(pts[i]-avg_err,2);
	}
	std_err/=pts.size();
	std_err = pow(std_err,0.5);
	opt_err = avg_err*1+max_err*0.5;
	std::cout << "================\n";
	std::cout << "average error: " << avg_err*100<<std::endl;
	std::cout << "optimized error: " << opt_err*100<<std::endl;
	std::cout << "standard deviation: " << std_err<<std::endl;
	std::cout << "Maximum error: " << max_err*100<<std::endl;
	std::cout << "Minimum error: " << min_err<<std::endl;
	std::cout << "================\n";
	pts.clear();
	// std::cout << "err: "<<err<<std::endl;
	delete distPTR;
	switch(err_type){
		case 0:
			return avg_err;
			break;
		case 1:
			return opt_err;
			break;
		case 2:
			return std_err;
			break;
		case 4:
			return max_err;
			break;
		case 5:
			return min_err;
			break;
	}
	// return getError();
}

double* Composite::solve_config(const char* objMeshname,const char* robot_data,const int& time){

	// passtime tic_toc; 
	// getParameters();
	updateConfig(objMeshname, robot_data);
	generateSheet();
	// cout << "[sheet constructed]"<<endl;
  	if (implicitBackwardEulerSparse != NULL)
  		delete implicitBackwardEulerSparse;
  	// cout << "[Solver cleared]"<<endl;
  	// getSolverInfo();
  	implicitBackwardEulerSparse = new ImplicitBackwardEulerSparse(3 * numVertices, timeStep, massMatrix, forceModel, numConstrainedDOFs, constrainedDOFs, dampingMass, dampingStiffness, 1, 1E-5, numSolverThreads);
  	// cout << "[Backward Solver init]"<<endl;
  	implicitNewmarkSparse = implicitBackwardEulerSparse;
  	integratorBase = implicitNewmarkSparse;
  	// cout << "[Solver initialized]"<<endl;
  	if (deform)
	  free(deform);
	if (f_ext)
	  free (f_ext);
	deform = (double*) malloc (sizeof(double) * 3 * numVertices);
	f_ext = (double*) malloc (sizeof(double) * 3 * numVertices);
	for(int i = 0 ; i < 3 * numVertices; i++)
	{
	    deform[i] = 0.0;
	    f_ext[i] = 0.0;
	}
	integratorBase->SetState(deform);
	integratorBase->SetExternalForces(f_ext);
	// cout << "[Solver constructed]"<<endl;


	// tic_toc.tic();
	for(int i=0; i<time; i++)
		integratorBase->DoTimestep();
	// tic_toc.toc();
	// cout << "[TimeStep:]"<< timeStep<<endl;

	memcpy(deform, integratorBase->Getq(), sizeof(double) * 3 * numVertices);
	if (sceneObjDeform != NULL)
    	delete sceneObjDeform;
    
  	sceneObjDeform = new SceneObjectDeformable(objMesh);

	sceneObjDeform->SetVertexDeformations(deform);
	return deform;
	
}