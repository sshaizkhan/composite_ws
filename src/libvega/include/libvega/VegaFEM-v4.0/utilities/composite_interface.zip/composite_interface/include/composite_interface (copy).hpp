#include <math.h>
#include <vector>
#include <string>
#include <sstream>
#include "objMesh.h"
#include "clothBWFromObjMesh.h"
#include "clothBWStencilForceModel.h"
#include "forceModelAssembler.h"
#include "implicitNewmarkSparse.h"
#include "implicitBackwardEulerSparse.h"
#include "sceneObjectDeformable.h"
#include "minivector.h"
#include <stack>
#include <ctime>
// #include "constrainedDOFs.h"
#include <fstream>
#include <iostream>

inline void parseTrainingData(const char* filename, std::vector<Vec3d>& fixed, std::vector<Vec3d>& point);

inline void shift(ObjMesh* obj, const std::vector<Vec3d>& fixed, std::vector<int>* groups, Vec3d* fvect);

inline Vec3d& groupCenter(ObjMesh* obj, const std::vector<Vec3d>& group);

struct point{
double x,y,z;
	friend std::ostream& operator << (std::ostream& out, const point& pt)
	{
		out << "["<<pt.x<<", "<<pt.y<<", " << pt.z<< "]"<< std::endl;
		return out;
	};
	friend std::ofstream& operator << (std::ofstream& fout, const point& pt)
	{
		fout <<pt.x<<","<<pt.y<<"," << pt.z<< std::endl;
		return fout;
	};
	friend point operator + (const  point& p1,const point& p2)
	{
		point result;
		result.x= p1.x+p2.x;
		result.y= p1.y+p2.y;
		result.z= p1.z+p2.z;
		return result;
	};
	friend point operator - (const point& p1,const point& p2)
	{
		point result;
		result.x= p1.x-p2.x;
		result.y= p1.y-p2.y;
		result.z= p1.z-p2.z;
		return result;
	};
	// friend point& operator += (const point& p2)
	// {
		
	// 	this->x+=p2.x;
	// 	this->y+=p2.y;
	// 	this->z+=p2.z;
	// 	return *this;
	// };
	// friend point& operator /= ( const float& scaler)
	// {
		
	// 	this->x/=scaler;
	// 	this->y/=scaler;
	// 	this->z/=scaler;
	// 	return *this;
	// };
	double length()
	{
		return sqrt( x*x+y*y+z*z );
	}
	double length(point& pt2)
	{
		return sqrt( (x-pt2.x)*(x-pt2.x)+
					(y-pt2.y)*(y-pt2.y)+
					(z-pt2.z)*(z-pt2.z) );
	}
	std::vector<point> loadpts(const char* name, const int offset)
	{
		std::fstream fin;
		fin.open(name);
		std::string line;
		std::vector<std::string> coord;
		std::string value;
		std::vector<point> data;
		point pts;
		data.clear();
		int count=0;
		while(getline(fin,line)){
			if(count >= offset)
			{
				std::stringstream ss(line);
				coord.clear();
				while(getline(ss,value,',')){
					coord.push_back(value);
				}
				pts.x=stod(coord[0]);
				pts.y=stod(coord[1]);
				pts.z=stod(coord[2]);
				data.push_back(pts);
			}
			count++;
		}
		std::cout <<"[ "<< data .size() <<" data points loaded]\n";
		return data;	
	}

};

struct passtime{
	std::stack<clock_t> tictoc_stack;
	double diff;
	void tic() {
    tictoc_stack.push(clock());
	}

	void toc() {
		diff = (((double)(clock() - tictoc_stack.top())) / CLOCKS_PER_SEC)/5.;
    std::cout << "[Time elapsed(sec)]: "
              << diff
              << std::endl;

    tictoc_stack.pop();
	}
	// double get(){return diff;}
};
class Composite
{
private:
    static bool instanceFlag;
    static Composite *sheet;
    
    //Physics Parameters
    //The one that will be updated from ML 
    float dampingMass;
	float dampingStiffness;
	float surfaceDensity;
	float tensileStiffness;
	float shearStiffness;
	float bendStiffnessU;
	float bendStiffnessV;
	//Const Parameters
	const float gravityForce=9.81;//9.81
	//Simulation and Calculation Parameters
	
	//Computation parameters (default to computing everything)
	int computeStretchShearForce, computeStretchShearStiffness, computeBendForce, computeBendStiffness;
	int numInternalForceThreads; // default = 0 (not multi-threaded)
	
	//solver parameters
	int numVertices=0;
	float timeStep=0.05;
	SparseMatrix * massMatrix;
	ForceModel * forceModel;
	  int numConstrainedDOFs = 0; 
	  int * constrainedDOFs = NULL;
	int numSolverThreads=2; // default = 0 (not multi-threaded)
	//Deformation Parameters
	double* deform = NULL;
	double* f_ext = NULL;
	//Model objects
	const char* meshname;
	ClothBW * clothBW;
	SceneObjectDeformable * sceneObjDeform;
	ClothBWStencilForceModel * clothBWStencilForceModel;
	ForceModelAssembler * forceModelAssembler;
	ObjMesh * objMesh;
	ClothBWFromObjMesh * clothBWFromObjMesh;
	IntegratorBase * integratorBase;
	ImplicitNewmarkSparse * implicitNewmarkSparse;
	ImplicitBackwardEulerSparse * implicitBackwardEulerSparse;
	std::vector<Vec3d> Realdata;
	
	std::vector<int> markerindex[90];
	std::vector<int> constrainGroups[3];
	//Fixed Vertex
	std::vector<int> fixedVertices;

	std::vector<point> deformdata;
	std::vector<Vec3d> testdata;
	Composite();
public:
    static Composite* getInstance();
    static void ResetInstance(){
    	delete sheet;
    	sheet = NULL;
    };
    void updateParam(const float* param);
    void updateParam(const std::vector<double>& param);
    void loadMesh(const char* objMeshname);//ptnNum will be updated here
    void generateSheet(const char* objMeshname,const float* param=NULL);//add physical parameters and force model
    void generateSheet(const char* objMeshname,const std::vector<double>& param);
    void generateSheet(const char* objMeshname,const char* fixedindex,const char* realcoordname,const std::vector<double>& param);
    void updateConstrain(const std::vector<int>& fix);
    int getFixfromfile(const char* filename);
    void getSolverInfo();
    void setTimeStep(const float& step);
    //data retrieve methods
    void method();
    void getParameters();
    void getData(const double* deformation,const char* objMeshname);
    std::vector<Vec3d> getVec3d(const char* realdataname);
    void shiftMesh(const Vec3d& offset);
    int UpdateFixPosition(const char* indexfilename, const char* realcoordname);
    Vec3d getGroupCenter(const std::vector<int>& group);
    void getMarkerData(const double * deformation,const char* objMeshname);
    double getError();
    // void saveData();
    //this is the main function
    //@p is the parameter array
    //@meshname is the file name of sheet mesh (.obj)
    //@fixed is the fixed vertex index
    //Return @deform is the deformation information
    std::vector<point>& solve(const char* objMeshname,const std::vector<int>& fixed,const float* param=NULL,const int& time=1000);
    std::vector<point>& solve(const char* objMeshname,const char* fixfilename,const float* param=NULL,const int& time=1000);
    std::vector<point>& solve(const char* objMeshname,const char* fixfilename,const std::vector<double>& param,const int& time=1000);
    std::vector<Vec3d>& solvegroup(const char* objMeshname,const char* fixedindex,const char* realcoordname,const std::vector<double>& param,const int& time=100);
    double solve_err(const char* objMeshname,const char* fixedindex,const char* realcoordname,const std::vector<double>& param,const int& time=100);
    
    ~Composite()
    {
    	if (implicitBackwardEulerSparse != NULL)
	    	delete implicitBackwardEulerSparse;
	  
	  if (clothBW != NULL)
	    delete clothBW;

	  if (clothBWFromObjMesh != NULL)
	    delete clothBWFromObjMesh;
	  
	  // render objs
	  if (objMesh != NULL)
	    delete objMesh;

	  if (sceneObjDeform != NULL)
	    delete sceneObjDeform;
	  // other
	  // if (deform)
	  //   free(deform);
	  // if (f_ext)
	  //   free(f_ext);
	        instanceFlag = false;

	  testdata.clear();
	  std::cout <<"sheet clear\n";

    }
};

	//TODO: parse training points
//      save them into fixed points and mesh point
//void parseTrainingData(filename, &fixedpoints, &meshpoints)
//save as vector<Vec3d>

inline void parseTrainingData(const char* filename, std::vector<Vec3d>& fixed, std::vector<Vec3d>& point, const int& ifCenter=0){
		std::fstream fin;
	  	fin.open(filename);
		if(!fin.is_open()){
			std::cout<<"open failed"<<std::endl;
		}
		std::string line;
		std::vector<std::string> coord;
		std::string value;
		// int count=0;
		int i=0;
		if(fixed.size()!=0)
			fixed.clear();
		if(point.size()!=0)
			point.clear();
		while(getline(fin,line)){
				std::stringstream ss(line);
				coord.clear();
				while(getline(ss,value,',')){
					coord.push_back(value);
				}

				if(i<12+ifCenter)
					fixed.push_back(Vec3d(stod(coord[0]),stod(coord[1]),stod(coord[2])));
				else
					point.push_back(Vec3d(stod(coord[0]),stod(coord[1]),stod(coord[2])));
				i++;
		}
}

//TODO: shift mesh to fix points
//void shift(*objmesh, &fixedpoints) in meter
inline void shift(ObjMesh* obj, const std::vector<Vec3d>& fixed, std::vector<int>* groups, Vec3d* fvect){
	std::vector<int> constrainGroups[3];
	Vec3d center[3];
	Vec3d offset[3];
	constrainGroups[0] = {598,1159,1161,1965,1967,1966};
	constrainGroups[1] = {720,721,722,2056,2058,2059,2060,2061};
	constrainGroups[2] = {838,2120,2121,2122,1388};
	for(int i=0; i<3; i++)
	{
	groups[i] = constrainGroups[i];		
	}

	// constrainGroups[0] = {3,671,1087,1088,2622,2623,2624,4223,4224};
	// constrainGroups[1] = {1,1032,1033,1065,2259,2502,4112,4113,4177};
	// constrainGroups[2] = {0,513,1009,1010,2139,2140,2141,4065,4066};
	
	center[0].set(0.0);
	for(int j= 0; j<constrainGroups[0].size(); j++){
		center[0]+=obj->getPosition(constrainGroups[0][j]);
	}
	center[0]/=constrainGroups[0].size();
	
	offset[0] = fixed[0] - center[0];
	for(int i=0; i<obj->getNumVertices();i++){
		obj->setPosition(i,obj->getPosition(i)+offset[0]);
	}
	for(int i=1; i<3; i++){
		center[i].set(0.0);
		for(int j= 0; j<constrainGroups[i].size(); j++){
			center[i]+=obj->getPosition(constrainGroups[i][j]);
		}
		center[i]/=constrainGroups[i].size();
	}

	for(int i=1; i<3; i++)
		offset[i] = fixed[i] - center[i];
	// fvect = new Vec3d[3];
	for(int i=0; i<3; i++)
		fvect[i] = offset[i];
	// for(int i=1; i<3; i++){
	// 	offset[i] = fixed[i] - center[i];
	// 	for(int j=0; j<constrainGroups[i].size();j++)
	// 		obj->setPosition(constrainGroups[i][j],obj->getPosition(constrainGroups[i][j])+offset[i]);
	// }

}





inline Vec3d groupCenter(ObjMesh* obj, const std::vector<int>& group){

	Vec3d center(0,0,0);
		
		for(int j= 0; j<group.size(); j++){
			center+=obj->getPosition(group[j]);
		}
		center/=group.size();
	return center;
}

inline Vec3d groupCenter(SceneObjectDeformable* obj, const std::vector<int>& group){
	Vec3d center(0,0,0);
	for(int j=0; j<group.size(); j++)
	{
		center+=obj->GetSingleVertexPositionFromBuffer(group[j]);
	}
	center/=group.size();
	return center;
}

inline void parseTrainingData(const char* filename, ObjMesh* obj, std::vector<Vec3d>& training_fix, 
								std::vector<Vec3d>& training_marker, std::vector<int>& fixgroups, const int& ifCenter){

	parseTrainingData(filename, training_fix, training_marker, ifCenter);
	for(int i=0; i< training_fix.size(); i++)
		fixgroups.push_back(obj->getClosestVertex(training_fix[i]));
	std::sort(fixgroups.begin(), fixgroups.end());

}


