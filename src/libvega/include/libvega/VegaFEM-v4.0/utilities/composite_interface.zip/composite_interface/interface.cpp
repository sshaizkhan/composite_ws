#include "composite_interface.hpp"
// #include "param_solver.hpp"
#include <vector>
#include <string>
#include <iostream>
#include <fstream>
// void save(std::vector<point> pts, char* filename)
// {
// 	std::ofstream myfile;
// 	myfile.open(filename);
// 	for(int i=0; i< pts.size(); i++)
// 		myfile<<pts[i];
// 	std::cout<<"file: "<<filename<<" saved"<<std::endl;
// 	myfile.close();
// }

int main()
{

	// //TEST
	// //*surfaceDensity tensileStiffness shearStiffness bendStiffnessU bendStiffnessV dampingMass dampingStiffness
	std::vector<std::vector<double>>Lb;
	std::vector<std::vector<double>>Ub;
	std::vector<std::vector<double>>Sol;
	std::vector<double> Ltemp;
	std::vector<double> Utemp;
	std::vector<double> pass_t;
	//First
	// Ltemp= {4.6e-7, 100, 100, 10, 10, 0.0, 0.1};
	// Utemp={4.61e-7, 1000, 1000, 1000, 1000, 0.0, 0.11};
	// Lb.push_back(Ltemp);
	// Ub.push_back(Utemp);

	// //tensileStiffness shearStiffness bendStiffnessU bendStiffnessV 
	// Ltemp= {100, 100, 10, 10};
	// Utemp={1000, 1000, 1000, 1000};
	// Lb.push_back(Ltemp);
	// Ub.push_back(Utemp);
	// // std::cout <<Lb[0][1]<<std::endl;
	// //Second
	// Ltemp= {900, 530, 10, 10};
	// Utemp={2000, 1500, 1000, 1000};
	// Lb.push_back(Ltemp);
	// Ub.push_back(Utemp);
	// //Third
	Ltemp= {1000, 1000, 0.0009};
	Utemp={9000, 9000, 0.0011};
	Lb.push_back(Ltemp);
	Ub.push_back(Utemp);

	// Ltemp= {5000, 5000};
	// Utemp={20000, 20000};
	// Lb.push_back(Ltemp);
	// Ub.push_back(Utemp);

	// std::vector<double> Lb= {100, 5e7, 5e7, 10, 10, 0.0, 0.1};
	// std::vector<double> Ub={100, 5e7, 5e7, 100, 100, 0.0, 0.1};
	// float p[7]={0.00219,5e7,5e7,100,100,0.0,0.1};//good param
	// float p[7]={100,5e7,5e7,10,10,0.0,0.1}; //extreme param
	// float p[7]={4.601e-7, 550, 550, 505, 505, 0.0, 0.101}; //initial param
	// float p[3]={5000, 5000,0.001}; //initial param
	float p[3]={8575.38, 8751.91, 0.000900105};
	// float p[7]={100,8500,100,0.01,0.01,0.0,0.001};
	// float p[7]={1,85,10,0.01,0.01,0.0,0.001};
	std::vector<double>vp;
	for(int i=0; i<(sizeof(p)/sizeof(*p));i++)
		vp.push_back(p[i]);
	// std::vector<const char*> meshnames, fixindexfiles, testname;
	std::vector<std::string> meshnames, training_data, robot_data;
	// std::vector<std::string> fixcoordfiles;
	const char* output = "/home/cam_sanding/VegaFEM-v4.0/utilities/composite_interface/param/param.txt";
	// // char* objMeshname="../../models/composite/rand_grid_data_90.obj";
	// // // char* fixfilename="../../models/composite/cloth5000.bou";
	// meshnames.push_back("../../examples/composite/sheet_90.obj");
	// // meshnames.push_back("../../examples/composite/sheet_90.obj");
	// // meshnames.push_back("../../models/cloth/bend1.obj");
	// fixindexfiles.push_back("../../models/composite/cloth5000.bou");
	std::string foldername = "/home/cam_sanding/camera_catkin_ws/src/ensenso_utilities/pcd_data";
	std::string meshpath;
	std::string trainingpath;
	std::string robotpath;
	for(int i=0; i<2;i++)
	{
		for(int j=0; j<5; j++){
			trainingpath = foldername + "/center_data/large_01292020/test/new_center_grip"+std::to_string(i+4)+"_curve_"+std::to_string(j+1)+".csv";
			meshpath = foldername + "/large_01292020/mesh"+std::to_string(i+4)+"_"+std::to_string(j+1)+".obj";
			robotpath = foldername + "/center_data/large_01292020/robot_data/new_center_grip"+std::to_string(i+4)+"_curve_"+std::to_string(j+1)+".csv";
			std::cout << trainingpath.data()<<std::endl;
			std::cout << meshpath.data()<<std::endl;
			meshnames.push_back(meshpath);
			meshpath.clear();
			training_data.push_back(trainingpath);
			trainingpath.clear();			
			robot_data.push_back(robotpath);
			robotpath.clear();
		}

	}
////////////////////////////////////////////////////////////////////
	// Composite *c1;
	// double err;
	// c1 = Composite::getInstance();
	// c1->setTimeStep(0.05);
	// std::vector<double> mesh_err;
	// double avg_err=0;
	// double std_err=0;
	// passtime tic_toc;
	// for(int i=0; i<meshnames.size(); i++)
	// {
	// 	if(i!=3 && i!=4)
	// 		std::cout <<"Training #"<<i+1<<std::endl;
	// 	else
	// 		std::cout <<"Testing #"<<i-2<<std::endl; 
	// 	tic_toc.tic();
	// 	err = c1->show_err(meshnames[i].data(),training_data[i].data(),vp,50,1);//0 avg, 1 opt, 2 std, 3 max, 4 min
	// 	tic_toc.toc();
	// 	// std::cout << "err: "<<err<<std::endl;
	// 	mesh_err.push_back(err);
	// 	avg_err+=err;
	// }
	// avg_err/=meshnames.size();
	// for(int i=0; i<mesh_err.size(); i++)
	// {
	// 	std_err += pow(mesh_err[i]-avg_err,2);
	// }
	// std_err/=mesh_err.size();
	// std_err = pow(std_err,0.5);
	// std::cout << "================\n";
	// std::cout << "average error: " << avg_err<<std::endl;
	// std::cout << "standard deviation: " << std_err<<std::endl;
	// std::cout << "================\n";
///////////////////////////////////////////////////////////////////////////////
	// Composite *c1;
	// double base_output;
	// double err;
	// double base_input;
	// double input_percent;
	// double output_percent;
	// double sen;
	// std::vector<double>vtest = vp;
	// c1 = Composite::getInstance();
	// c1->setTimeStep(0.01);
	// // std::vector<double> mesh_err;
	// double avg_sen=0;
	// base_output = c1->solve_err(meshnames[0].data(),training_data[0].data(),vtest,100);
	// // c1->getParameters();
	// std::cout << "out: "<< base_output<<std::endl;
	// // double std_err=0;
	// for(int j=0; j<3; j++){

	// 	vtest[j] = vp[j]*1.5;

	// 	// for(int i=0; i<9; i++)
	// 	// {
	// 	// 	if(j==2)
	// 	// 		vp[j] = (i+1)*0.001;
	// 	// 	else
	// 	// 		vp[j] = (i+1)*1000;

	// 	// 	input_percent = std::abs(vp[j]-base_input)/base_input;
	// 	// 	// std::cout << "input percent" << input_percent<<std::endl;
	// 	// 	err = c1->solve_err(meshnames[0].data(),training_data[0].data(),vp,100);
	// 	// 	// c1->getParameters();
	// 	// 	// std::cout << "err: "<< err << std::endl;
	// 	// 	// std::cout << "base_output: "<< base_output << std::endl;
	// 	// 	output_percent = std::abs(err-base_output)/base_output;
	// 	// 	// sen = output_percent/input_percent;
	// 	// 	// std::cout << "#"<<i+1 <<": " << sen<<std::endl;
	// 	// 	// avg_sen+=sen;
	// 	// }
	// 	// avg_sen/=9;
	// 	err = c1->solve_err(meshnames[0].data(),training_data[0].data(),vtest,100);
	// 	// c1->getParameters();
	// 	std::cout << "+10 out: "<< err<<std::endl;

	// 	vtest[j] = vp[j]*0.5;
	// 	err = c1->solve_err(meshnames[0].data(),training_data[0].data(),vtest,100);
	// 	// c1->getParameters();
	// 	std::cout << "-10 out: "<< err<<std::endl;
	// 	vtest[j] = vp[j];
	// }

	// avg_err/=10;
	// for(int i=0; i<mesh_err.size(); i++)
	// {
	// 	std_err += pow(mesh_err[i]-avg_err,2);
	// }
	// std_err/=mesh_err.size();
	// std_err = pow(std_err,0.5);
	// std::cout << "================\n";
	// std::cout << "average error: " << avg_err<<std::endl;
	// std::cout << "standard deviation: " << std_err<<std::endl;
	// std::cout << "================\n";


//////////////////////Pipe_line Test/////////////////////////
	Composite *c1;
	double* deform;
	c1 = Composite::getInstance();
	c1->setTimeStep(0.05);
	c1->updateParam(vp);
	passtime tic_toc;
	tic_toc.tic();
	for(int i=0; i<meshnames.size(); i++)
	{
		if(i!=3 && i!=4 && i!=8 && i!=9)
			std::cout <<"Training #"<<i+1<<std::endl;
		else
			std::cout <<"Testing #"<<i-2<<std::endl; 
		
		deform = c1->solve_config(meshnames[i].data(),robot_data[i].data(),1);
		


	}
	tic_toc.toc();
	// std::cout<<"deform check:"<<deform[0]<<std::endl;
///////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////
	// Param_Solver* ps;
	// // // passtime tic_toc;
	// nlopt::algorithm alg_type = nlopt::GN_ISRES;
	// // // // // //////ps(nlopt::algorithm& Algo, const int& max_iter,  const std::vector<const char*>& meshname,
 // //                //  const std::vector<const char*>& init_data,
 // //                // const std::vector<const char*>& training_data,
 // //                // const std::vector<double>& _X_init,const double& OptH,const double& OptXtolRel,const double& OptFtolRel,
 // //                // const std::vector<double> LBounds, const std::vector<double> UBounds,const double& timeStep, const unsigned int simulate_time=100)
	// // // // // for(int i=0; i<Lb.size(); i++)
	// // // // // {
	// // // // // 	if(i==1)
	// // // // // 	{
			
	// // // // 		// Param_Solver ps(meshnames[0],fixindexfiles[0],testname[0],0,vp,1e-8,1e-8,Lb,Ub,0.02,100);
			// ps = new Param_Solver(alg_type, 3000,meshnames,training_data, vp,1e-6,1e-8,1e-8,Lb[0],Ub[0],0.01,100);
	// // // 		tic_toc.tic();
			// ps->solveOPT();
			// ps->checksol();
	// // // 		Sol.push_back(ps->get_solx());
	// // // 		tic_toc.toc();
	// // // // 		std::cout <<"[ Total "<<ps->iter<<" ] done"<<std::endl;
	// // // 		pass_t.push_back(tic_toc.diff);
			// ps->savesol(output);

			// vp = ps->get_solx();
			// delete ps;
			// ps = NULL;
			// alg_type = nlopt::LD_LBFGS;
	// 		// vp = 8575.38 8751.91 0.000900105
	// 		// tic_toc.tic();
	// // // // 		// Param_Solver ps(meshnames[0],fixindexfiles[0],testname[0],0,vp,1e-8,1e-8,Lb,Ub,0.02,100);
			// ps = new Param_Solver(alg_type, 5000,meshnames,training_data, vp,1e-8,1e-8,1e-8,Lb[0],Ub[0],0.01,100);
			// ps->solveOPT();
			// ps->checksol();
	// 		Sol.push_back(ps->get_solx());
	// 		// tic_toc.toc();
	// 		// std::cout <<"[ Total "<<ps->iter<<" ] done"<<std::endl;
	// 		pass_t.push_back(tic_toc.diff);
			// ps->savesol(output);
	// // 	}

	// // }
	


	//  // tic_toc.tic();
	// for(int i=0; i<Sol.size();i++){
	// 	std::cout <<"[ Sol #"<<i+1<<" :" ;
	// 	for(int j=0; j<Sol[0].size();j++){
	// 		std::cout <<" "<<Sol[i][j];
	// 	}
	// 		std::cout <<"]\n";
	// 		std:: cout << "Total time: "<< pass_t[i]<<std::endl;
	// }
	// tic_toc.toc();
	// pass_t.push_back(tic_toc.diff);
	// std:: cout << pass_t[0]<<std::endl;
	return 0;
}

