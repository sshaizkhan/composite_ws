#include "param_solver.hpp"
#include <algorithm>
#include "stdlib.h"
#include <vector>
#include <string>
#include <cmath>
#include <fstream>
#include <iostream>
using namespace std;
double customminfunc(const std::vector<double>& x, std::vector<double>& grad, void* data) 
{
    // Because we wanted a Class
    // without static members, but NLOpt library does not support
    // passing methods of Classes, we use these auxilary functions.
    Param_Solver *ps = (Param_Solver *) data;
    // cout <<"im here\n";
    return ps->ObjFun(x,grad);
}

Param_Solver::Param_Solver(nlopt::algorithm& Algo, const int& max_iter, const std::vector<std::string>& meshname,
                const std::vector<std::string>& training_data,
                const std::vector<double>& _X_init,const double& OptH,const double& OptXtolRel,const double& OptFtolRel,
                const std::vector<double> LBounds, const std::vector<double> UBounds,const double& timeStep, const unsigned int simulate_time)
{
	        //choose optimizer
        // alg_type = nlopt::LN_NEWUOA;
        // alg_type = nlopt::LN_NEWUOA_BOUND;
        // alg_type = nlopt::LD_MMA;
        // alg_type = nlopt::LD_TNEWTON_PRECOND_RESTART;
        // alg_type = nlopt::LN_BOBYQA;
        // alg_type = nlopt::LN_COBYLA;
        // alg_type = nlopt::LD_SLSQP;
        alg_type = nlopt::LD_LBFGS;
        // alg_type = nlopt::GN_ISRES;

        alg_type = Algo;
        maxeval = max_iter;
        sheet_timestep = timeStep;
        sheet = Composite::getInstance();
        sheet->setTimeStep(sheet_timestep);
    	objmeshname = meshname;
        Training_data_file = training_data;
	    // FixptsFile = fixpts;
	    // RealdataFile = dataname;
	    
	    X_init = _X_init;
        optH = OptH;
        optXtolRel = OptXtolRel;
        optFtolRel = OptFtolRel;
        //Optimization Parameters
        OptVarDim = _X_init.size();
        opt = nlopt::opt(alg_type, OptVarDim);
        OptVarlb.resize(OptVarDim);
        OptVarub.resize(OptVarDim);
        OptVarlb = LBounds;
        OptVarub = UBounds;
        cout << "[Param Dimention: "<< OptVarDim<<" ]" <<endl;
        Simulation_time = simulate_time;
        opt.set_xtol_rel(optXtolRel);//if the step doesn't change much in param
        opt.set_min_objective(customminfunc, this);
        opt.set_lower_bounds(OptVarlb);
        opt.set_upper_bounds(OptVarub);
        opt.set_ftol_rel(optFtolRel);//if the step doesn't change much in grad
        opt.set_population(50);
        opt.set_maxeval(maxeval);
        cout << "[Param_Solver constructed]"<<endl;
        iter = 0;
        // optx.resize(OptVarDim);

}

// double Param_Solver::ErrFun(const std::vector<double> &x)
// {
// 	// cout << "[Enter ERRFun]"<<endl;
// 	// double err;
// 	// double total_err=0;
//  //    // double max = 0;
// 	// // cout << "[Current parameter:";
// 	// // for(int i=0; i<x.size(); i++)
// 	// // 	cout <<" " <<x[i];
// 	// // cout << "]\n";

// 	// for(int i=0; i<RealdataFile.size();i++)
// 	// {
// 	// 	err = sheet->solve_err(objmeshname,FixptsFile,RealdataFile[i].data(),x,Simulation_time);
//  //        if(max<err)
//  //            max = err;
// 	// 	// cout << "#"<< i+1<<" err:"<< err<<endl;
// 	// 	total_err+=err;
// 	// }
	
// 	// total_err/=RealdataFile.size();
//  //    // total_err = total_err*0.75+max*0.25;
// 	// if(min_err>total_err){

// 	// 	min_err = total_err;		
// 	// 	savesol(x);
// 	// }
// 	// // std::cout <<"[ #"<<iter<<" ] 30 files done"<<std::endl;
// 	// sheet -> ResetInstance();
// 	// sheet = Composite::getInstance();
//  //    sheet->setTimeStep(sheet_timestep);
//  //    return total_err;
// }

double Param_Solver::ErrFun(const std::vector<double> &x)
{
    // cout << "[Enter ERRFun]"<<endl;
    double err;
    double total_err=0;
    // double max = 0;
    // // cout << "[Current parameter:";
    // // for(int i=0; i<x.size(); i++)
    // //   cout <<" " <<x[i];
    // // cout << "]\n";

    for(int i=0; i<objmeshname.size();i++)
    {
     err = sheet->solve_err(objmeshname[i].data(),Training_data_file[i].data(),x,Simulation_time);
        // if(err>max)
        //     max = err;
     // cout << "#"<< i+1<<" err:"<< err<<endl;
     total_err+=err;
     // std::cout << "total_err: "<<total_err<<std::endl;
    }
    
    // total_err-=max;
    // std::cout << "total_err: "<<total_err<<std::endl;
    total_err/=objmeshname.size();
 //    // total_err = total_err*0.75+max*0.25;
    if(min_err>total_err){

     min_err = total_err;        
     savesol(x);
    }
    // std::cout <<"[ #"<<iter<<" ] 30 files done"<<std::endl;
    // std::cout << "total_err: "<<total_err<<std::endl;
    sheet -> ResetInstance();
    sheet = Composite::getInstance();
    sheet->setTimeStep(sheet_timestep);
    return total_err;
}

// gradient computation:
// Forward Difference Method
double Param_Solver::ObjFun(const std::vector<double> &x, std::vector<double> &grad)
{
	// cout << "[Enter ObjFun]"<<endl;
	cout << "[Current parameter:";
	for(int i=0; i<x.size(); i++)
		cout <<" " <<x[i];
	cout << "]\n";
    double err = ErrFun(x);
    // cout <<"grad empty"<<endl;
    if (!grad.empty()) {
        std::vector<double> xph = x;
        // cout <<"grad:";
        for (uint i=0; i < x.size(); ++i)
        {
            
                xph[i] += optH;
                grad[i] = (ErrFun(xph)-err)/optH;
                xph[i] -= optH;
            

            // cout << " " <<grad[i];
        }
        cout <<"grad :"<<endl;
        for(uint i=0; i<grad.size(); i++){
        	cout << " " <<grad[i];
        }
        cout <<"\n";
        

    }    
    iter++;

    std::cout <<"[ #"<<iter<<" ]" << objmeshname.size()<<" files done ERR: "<<err <<std::endl;
    return err;
};


bool Param_Solver::solveOPT()
{
    solx = X_init;
    bool successFlag = false;
    try{
        
        nlopt::result result = opt.optimize(solx, solminf);
        cout <<"Result: "<<result<<endl;
        if(result == 3)
        	cout<<"NLOPT_FTOL_REACHED\n";
        else if(result == 4)
        	cout<<"NLOPT_XTOL_REACHED\n";
        successFlag = true;
    }
    catch(std::exception &e) {
        std::cout << "nlopt failed: " << e.what() << std::endl;
    }
    return successFlag;
};

double Param_Solver::get_solminf()
{
    return solminf;
};

std::vector<double> Param_Solver::get_solx()
{
    return solx;
};

void Param_Solver::checksol(){
	cout <<"[ Sol:" ;
	for(int i=0; i<solx.size();i++)
		cout <<" "<<solx[i];
	cout <<"]\n" ;
}

void Param_Solver::savesol(const char* Outputfile){
		ofstream fout;
		if(alg_type != nlopt::LD_LBFGS)
			Outputfile ="/home/cam_sanding/VegaFEM-v4.0/utilities/composite_interface/param/param_globe.txt";
		fout<<"# "<< iter<<" :";
		fout <<"[ Sol:" ;
		for(int i=0; i<solx.size();i++)
			fout <<" "<<solx[i];
		fout <<"]\n" ;
		cout <<"file saved to "<< Outputfile<<endl;

}

void Param_Solver::savesol(const std::vector<double> &x){
		ofstream fout;
		if(alg_type == nlopt::LD_LBFGS)
			fout.open("/home/cam_sanding/VegaFEM-v4.0/utilities/composite_interface/param/param.txt");
		else
			fout.open("/home/cam_sanding/VegaFEM-v4.0/utilities/composite_interface/param/param_globe.txt");
		fout<<"# "<< iter<<" :";
		fout <<"[ Current Sol(" << min_err<<"): ";
		for(int i=0; i<x.size();i++)
			fout <<" "<<x[i];
		fout <<"]\n" ;
		cout <<"file saved"<<endl;	
}